# 2_make_gap_dataset.py
import json, random, re
from pathlib import Path
import argparse

# 简单 tokenizer-like split by whitespace/punct for selecting gap spans
_WORD_RE = re.compile(r'\S+')

def read_jsonl(p):
    with open(p, "r", encoding="utf-8") as f:
        return [json.loads(l) for l in f]

def write_jsonl(rows, p):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

def find_tokens(s):
    # 返回所有匹配的 (start, end, token)
    return [m for m in _WORD_RE.finditer(s)]

def make_gaps_from_target(target, rng, max_gaps=3, rates=None):
    # rates: dict of proportions for gap types
    # 返回 list of gaped strings (input sketch) 与 mask spans positions (char indices)
    if rates is None:
        rates = {"single": 0.3, "short": 0.3, "mid": 0.25, "block": 0.15}
    tokens = find_tokens(target)
    n = len(tokens)
    if n == 0:
        return []
    results = []
    # decide number of gaps this sample will contain
    ng = rng.randint(1, max_gaps)
    used = set()
    for _ in range(ng):
        t = rng.random()
        if t < rates["single"]:
            # single token gap
            idx = rng.randint(0, n - 1)
            if idx in used: continue
            m = tokens[idx]
            s, e = m.start(), m.end()
            results.append((s, e))
            used.add(idx)
        elif t < rates["single"] + rates["short"]:
            # short (1-3 tokens)
            idx = rng.randint(0, max(0, n - 1))
            length = rng.randint(1, min(3, n - idx))
            spans = []
            for j in range(length):
                if idx + j in used: break
                m = tokens[idx + j]; spans.append((m.start(), m.end())); used.add(idx + j)
            if spans:
                s, e = spans[0][0], spans[-1][1]
                results.append((s, e))
        elif t < rates["single"] + rates["short"] + rates["mid"]:
            # mid: a whole tactic line heuristics: find newline boundaries
            # pick a random newline-separated line
            lines = target.splitlines()
            if len(lines) == 0:
                continue
            line_idx = rng.randint(0, len(lines) - 1)
            # compute char offsets
            offset = sum(len(L) + 1 for L in lines[:line_idx])
            s = offset
            e = offset + len(lines[line_idx])
            results.append((s, e))
        else:
            # block: try to pick a := by block span if exists, else fall back to multi-line
            m_block = re.search(r':=\s*by\b', target)
            if m_block:
                start = m_block.start()
                # cut until next top-level blank line or end
                rest = target[start:]
                # simple heuristic: find next double newline
                dn = rest.find("\n\n")
                if dn == -1:
                    s = start
                    e = len(target)
                else:
                    s = start
                    e = start + dn
                results.append((s, e))
            else:
                # fallback to mid
                lines = target.splitlines()
                idx = rng.randint(0, max(0, len(lines)-1))
                offset = sum(len(L)+1 for L in lines[:idx])
                s = offset; e = offset + len(lines[idx])
                results.append((s, e))
    # merge overlapping spans
    if not results:
        return []
    results_sorted = sorted(results)
    merged = []
    cur_s, cur_e = results_sorted[0]
    for s,e in results_sorted[1:]:
        if s <= cur_e:
            cur_e = max(cur_e, e)
        else:
            merged.append((cur_s, cur_e))
            cur_s, cur_e = s, e
    merged.append((cur_s, cur_e))
    return merged

def apply_gaps(target, spans):
    # produce gaped string and a map of spans to the original substring
    tgt = target
    offset = 0
    pieces = []
    removed_spans = []
    last = 0
    for s,e in spans:
        pieces.append(tgt[last:s])
        pieces.append("<GAP>")
        removed_spans.append(tgt[s:e])
        last = e
    pieces.append(tgt[last:])
    return "".join(pieces), removed_spans

def generate_gap_dataset(input_jsonl, out_jsonl, mix_full_ratio=0.1, rng_seed=42, max_gaps=3):
    rng = random.Random(rng_seed)
    rows = read_jsonl(input_jsonl)
    out = []
    for r in rows:
        full = r["target"]
        # skip empty
        if not full.strip():
            continue
        # produce a few gap variants per full sample
        n_variants = 3
        for vi in range(n_variants):
            spans = make_gaps_from_target(full, rng, max_gaps=max_gaps)
            if not spans:
                continue
            gaped, removed = apply_gaps(full, spans)
            # input: header/theorem + sketch with <GAP> markers
            inp = r["input"].rstrip() + "\n" + gaped
            out.append({"id": r.get("id"), "name": r.get("name"), "input": inp, "target": full, "gaps": spans})
    # optionally mix some full (no-gap) samples to avoid forgetting
    n_mix = int(len(out) * mix_full_ratio)
    if n_mix > 0:
        for i in range(n_mix):
            pick = rng.choice(rows)
            out.append({"id": pick.get("id"), "name": pick.get("name"), "input": pick["input"], "target": pick["target"], "gaps": []})
    random.shuffle(out)
    write_jsonl(out, out_jsonl)
    print(f"wrote {len(out)} gap samples to {out_jsonl}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_jsonl", required=True)
    ap.add_argument("--out_jsonl", required=True)
    ap.add_argument("--mix_full_ratio", type=float, default=0.1)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()
    generate_gap_dataset(args.in_jsonl, args.out_jsonl, mix_full_ratio=args.mix_full_ratio, rng_seed=args.seed)