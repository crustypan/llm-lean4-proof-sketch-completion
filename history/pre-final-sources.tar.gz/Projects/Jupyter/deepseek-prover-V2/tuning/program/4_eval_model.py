# 4_eval_model.py
import json, math, time
from pathlib import Path
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel, PeftConfig, PeftModel
import argparse
import jsonlines

# Assumes you have judgement(header, candidate) -> (verdict, log, time_sec)
# from your existing code. Import it here.
# from your_judgement_module import judgement, brief_error

def load_model_peft(base_model_dir, peft_dir):
    # load base model (quantization optional), then load peft weights
    tokenizer = AutoTokenizer.from_pretrained(base_model_dir, use_fast=False, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(base_model_dir, device_map="auto", trust_remote_code=True)
    model = PeftModel.from_pretrained(model, peft_dir, device_map="auto")
    return tokenizer, model

def generate_candidates(tokenizer, model, prompt, gen_cfg):
    input_ids = tokenizer(prompt, return_tensors="pt").to(next(model.parameters()).device).input_ids
    out = model.generate(
        input_ids,
        max_new_tokens=gen_cfg.get("max_new_tokens", 1024),
        do_sample=gen_cfg.get("do_sample", True),
        top_p=gen_cfg.get("top_p", 0.95),
        temperature=gen_cfg.get("temperature", 0.8),
        num_return_sequences=gen_cfg.get("num_return_sequences", 4),
        pad_token_id=tokenizer.eos_token_id,
    )
    results = [tokenizer.decode(o[input_ids.shape[1]:], skip_special_tokens=True) for o in out]
    return results

def main(model_dir, peft_dir, test_jsonl, header_prefix="", gen_cfg=None, out_dir="runs/eval"):
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    tokenizer, model = load_model_peft(model_dir, peft_dir)
    # load test file
    with open(test_jsonl, "r", encoding="utf-8") as f:
        tests = [json.loads(l) for l in f]

    summary_path = Path(out_dir) / "summary.jsonl"
    writer = jsonlines.open(summary_path, mode="w")
    try:
        for i, rec in enumerate(tests, 1):
            inp = rec["input"]
            # full prompt: optionally prepend header_prefix
            prompt = (header_prefix + "\n\n" + inp).strip()
            cand_list = generate_candidates(tokenizer, model, prompt, gen_cfg or {})
            attempts = []
            success = 0
            for j, cand in enumerate(cand_list, 1):
                # judge using your judgement function (must be available)
                verdict, log, t = ("FAIL", "", 0.0) # placeholder
                # verdict, log, t = judgement(header_prefix, cand)
                ok = (verdict == "PASS")
                success += int(ok)
                attempts.append({"index": j, "pass": ok, "verdict": verdict, "time_sec": t, "log": log, "model_output": cand})
            pass_at_1 = 1.0 if success > 0 else 0.0
            rec_out = {"id": rec.get("id"), "name": rec.get("name"), "attempts": attempts, "pass@1": pass_at_1}
            writer.write(rec_out)
    finally:
        writer.close()

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model_dir", required=True)   # base model dir (or hf id)
    ap.add_argument("--peft_dir", required=True)         # saved peft/LoRA dir (e.g., output_dir/stageB)
    ap.add_argument("--test_jsonl", required=True)
    ap.add_argument("--out_dir", default="runs/eval")
    args = ap.parse_args()
    gen_cfg = {"max_new_tokens": 1024, "do_sample": True, "top_p":0.95, "temperature":0.8, "num_return_sequences":4}
    main(args.base_model_dir, args.peft_dir, args.test_jsonl, header_prefix="", gen_cfg=gen_cfg, out_dir=args.out_dir)