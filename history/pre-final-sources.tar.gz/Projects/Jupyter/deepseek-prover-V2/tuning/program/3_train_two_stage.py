# 3_train_two_stage.py
import os
import json
from pathlib import Path
import argparse
from datasets import load_dataset
from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments, BitsAndBytesConfig
from trl import SFTTrainer
from peft import LoraConfig
import math
import random
import time
# import your judgement if you want to run eval during training
# from your_judgement_module import judgement, brief_error

def load_jsonl_as_dataset(p):
    return load_dataset("json", data_files=str(p), split="train")

def simple_formatting_full(examples, tokenizer=None):
    # examples: batch from dataset with fields "input" and "target"
    # Return list[str] full prompt+response strings; SFTTrainer will mask prompt automatically using response_template
    out = []
    for inp, tgt in zip(examples["input"], examples["target"]):
        # ensure response separator matches response_template below
        prompt = inp.rstrip() + "\n\n```lean4\n"
        out.append(prompt + tgt)
    return out

def simple_formatting_gap(examples, tokenizer=None):
    # input contains "<GAP>" markers for missing spans. We want model to fill them.
    out = []
    for inp, tgt in zip(examples["input"], examples["target"]):
        # Use same response marker
        prompt = inp.rstrip() + "\n\n```lean4\n"
        out.append(prompt + tgt)
    return out

def run_stage(stage_name, model_name_or_path, train_jsonl, eval_jsonl, output_dir,
              use_qlora=True, max_seq_len=4096, per_device_bs=1, grad_acc=16,
              lr=1e-4, epochs=3, bf16=False, fp16=True, save_steps=500, eval_steps=500,
              resume_from=None):
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    # tokenizer
    tok = AutoTokenizer.from_pretrained(model_name_or_path, use_fast=False, trust_remote_code=True)
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token

    # quantization config
    quant_cfg = None
    if use_qlora:
        quant_cfg = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype="float16",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
        )

    # load model (supports device_map auto for multi-gpu with accelerate)
    model = AutoModelForCausalLM.from_pretrained(
        model_name_or_path,
        trust_remote_code=True,
        device_map="auto",
        quantization_config=quant_cfg,
    )

    # LoRA config
    peft_cfg = LoraConfig(
        r=32, lora_alpha=32, lora_dropout=0.1,
        target_modules="all-linear",
        task_type="CAUSAL_LM",
    )

    # datasets
    ds_train = load_jsonl_as_dataset(train_jsonl)
    ds_eval  = load_jsonl_as_dataset(eval_jsonl) if eval_jsonl else None

    # choose formatting function based on stage
    fmt = simple_formatting_full if stage_name == "A" else simple_formatting_gap

    # training args
    args = TrainingArguments(
        output_dir=output_dir,
        num_train_epochs=epochs,
        per_device_train_batch_size=per_device_bs,
        per_device_eval_batch_size=per_device_bs,
        gradient_accumulation_steps=grad_acc,
        evaluation_strategy="steps" if ds_eval is not None else "no",
        eval_steps=eval_steps,
        save_strategy="steps",
        save_steps=save_steps,
        save_total_limit=3,
        learning_rate=lr,
        bf16=bf16,
        fp16=fp16 and not bf16,
        logging_steps=50,
        lr_scheduler_type="cosine",
        warmup_ratio=0.03,
        report_to="tensorboard",
    )

    trainer = SFTTrainer(
        model=model,
        tokenizer=tok,
        train_dataset=ds_train,
        eval_dataset=ds_eval,
        peft_config=peft_cfg,
        max_seq_length=max_seq_len,
        packing=False,
        formatting_func=lambda ex: fmt(ex, tokenizer=tok),
        response_template="```lean4\n",
        dataset_num_proc=4,
        args=args
    )

    # resume from LoRA checkpoint if provided
    if resume_from:
        print(f"Loading PEFT checkpoint from {resume_from}")
        trainer.load_pretrained(resume_from)

    # train
    trainer.train()
    # save model and tokenizer and peft weights
    trainer.save_model(output_dir)
    tok.save_pretrained(output_dir)
    print(f"Stage {stage_name} finished and saved to {output_dir}")

    return output_dir

def main(args):
    # Stage A
    out_a = Path(args.output_dir) / "stageA"
    run_stage(
        stage_name="A",
        model_name_or_path=args.model_name_or_path,
        train_jsonl=args.train_full,
        eval_jsonl=args.val_full,
        output_dir=str(out_a),
        use_qlora=not args.disable_qlora,
        max_seq_len=args.max_seq_len,
        per_device_bs=args.per_device_bs,
        grad_acc=args.grad_acc,
        lr=args.lr_a,
        epochs=args.epochs_a,
        bf16=args.bf16,
        fp16=args.fp16,
        save_steps=args.save_steps,
        eval_steps=args.eval_steps,
    )

    # Stage B: gap-focused, load from A checkpoint
    out_b = Path(args.output_dir) / "stageB"
    run_stage(
        stage_name="B",
        model_name_or_path=str(out_a),   # load from A checkpoint dir
        train_jsonl=args.train_gap,
        eval_jsonl=args.val_gap if args.val_gap else args.val_full,
        output_dir=str(out_b),
        use_qlora=not args.disable_qlora,
        max_seq_len=args.max_seq_len,
        per_device_bs=args.per_device_bs,
        grad_acc=args.grad_acc,
        lr=args.lr_b,
        epochs=args.epochs_b,
        bf16=args.bf16,
        fp16=args.fp16,
        save_steps=args.save_steps,
        eval_steps=args.eval_steps,
        resume_from=str(out_a)
    )

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--model_name_or_path", required=True)
    ap.add_argument("--train_full", required=True)
    ap.add_argument("--val_full", required=True)
    ap.add_argument("--train_gap", required=True)
    ap.add_argument("--val_gap", default=None)
    ap.add_argument("--output_dir", required=True)
    ap.add_argument("--max_seq_len", type=int, default=4096)
    ap.add_argument("--per_device_bs", type=int, default=1)
    ap.add_argument("--grad_acc", type=int, default=16)
    ap.add_argument("--disable_qlora", action="store_true")
    ap.add_argument("--lr_a", type=float, default=1e-4)
    ap.add_argument("--lr_b", type=float, default=5e-5)
    ap.add_argument("--epochs_a", type=int, default=4)
    ap.add_argument("--epochs_b", type=int, default=6)
    ap.add_argument("--save_steps", type=int, default=500)
    ap.add_argument("--eval_steps", type=int, default=500)
    ap.add_argument("--bf16", action="store_true")
    ap.add_argument("--fp16", action="store_true")
    args = ap.parse_args()
    main(args)