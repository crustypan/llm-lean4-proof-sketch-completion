# 1_prepare_data.py
import json
import random
from pathlib import Path
import argparse

def read_jsonl(p):
    with open(p, "r", encoding="utf-8") as f:
        return [json.loads(l) for l in f]

def write_jsonl(rows, p):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

def make_pair(r, use_header=True):
    header = (r.get("header") or "").rstrip()
    theorem = r.get("theorem") or ""
    sketch = r.get("sketch") or ""
    # 输入上下文：header + theorem + sketch
    if use_header:
        ctx = header + "\n\n" + theorem + "\n" + sketch
    else:
        ctx = theorem + "\n" + sketch
    tgt = r.get("lean_block") or r.get("lean_proof") or ""
    return {"id": r.get("id"), "name": r.get("name"), "input": ctx, "target": tgt, "orig": r}

def main(src, out_dir, val_frac=0.1, seed=42):
    rows = read_jsonl(src)
    valid_rows = [r for r in rows if r.get("split") == "valid"]
    test_rows  = [r for r in rows if r.get("split") == "test"]
    random.seed(seed)
    random.shuffle(valid_rows)
    n_val = max(1, int(len(valid_rows) * val_frac))
    val = valid_rows[:n_val]
    train = valid_rows[n_val:]
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl([make_pair(r) for r in train], out_dir / "train_full.jsonl")
    write_jsonl([make_pair(r) for r in val], out_dir / "val_full.jsonl")
    write_jsonl([make_pair(r) for r in test_rows], out_dir / "test.jsonl")
    print(f"train={len(train)} val={len(val)} test={len(test_rows)}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--val_frac", type=float, default=0.1)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()
    main(args.src, args.out_dir, args.val_frac, args.seed)