# make_sketches.py
import json, jsonlines, re, random
from pathlib import Path
from typing import List, Dict

# ------------- 基础工具 -------------
TOP_DECL_RE = re.compile(r'^(theorem|lemma|example)\b', re.M)
BY_BLOCK_RE = re.compile(r':=\s*by\b', re.M)

def split_header_and_statement(lean_src: str):
    """
    粗略切：把 header(import/open/set_option/section 等) 与第一个 theorem/lemma 分开。
    若已经分好，可直接传入。
    """
    m = TOP_DECL_RE.search(lean_src)
    if not m:
        return lean_src.strip(), ""  # 没找到定理，全部当 header
    return lean_src[:m.start()].strip(), lean_src[m.start():].strip()

def find_by_spans(the_body: str) -> List[tuple]:
    """
    在定理/证明体里找所有 ':= by ...' 的起点，返回 (start_idx, end_idx) 的粗略块范围。
    做草图只需要把 'by' 后面的内容替换为占位符；这里用缩进/空行/下一个顶层的 'theorem/lemma' 近似截断。
    """
    spans = []
    for m in BY_BLOCK_RE.finditer(the_body):
        start = m.end()
        # 终点：到下一个顶层声明或文件末
        next_decl = TOP_DECL_RE.search(the_body, pos=start)
        end = next_decl.start() if next_decl else len(the_body)
        spans.append((start, end))
    return spans

def apply_gaps(the_body: str, mode="holes", gap_ratio=0.7, gap_token="<GAP>"):
    body = the_body
    spans = find_by_spans(body)
    if not spans:
        return body, 0

    # 需要打洞的 indices
    idxs = list(range(len(spans)))
    random.shuffle(idxs)
    k = max(1, int(len(spans) * gap_ratio))
    use = set(idxs[:k]) if mode in ("holes", "mask-by", "outline") else set(idxs)

    # 自后向前替换，避免索引偏移
    num = 0
    for i in reversed(range(len(spans))):
        s, e = spans[i]
        if i in use:
            # 把 'by ...' 的内容替换成占位提示
            body = body[:s] + f"\n  -- <sketch gap>\n  {gap_token}\n" + body[e:]
            num += 1
        elif mode == "outline":
            # outline 模式：即使没在 use，也全部打掉
            body = body[:s] + f"\n  -- <sketch gap>\n  {gap_token}\n" + body[e:]
            num += 1
        # 否则保留原样
    return body, num

def build_sketch_record(rec: Dict, modes=("holes","mask-by","outline"),
                        gap_ratio=0.7, per_mode=1, gap_token="<GAP>",
                        dump_dir: str | None = None) -> List[Dict]:
    """
    从一条 PASS 样本构造多条 sketch 变体。
    支持：把 rec["header"] + rec["lean_block"]（或 formal_statement+proof）重组。
    """
    header = (rec.get("header") or "").strip()
    # lean_block 里通常含有 theorem ... := by ... 的完整代码
    full_src = (rec.get("lean_block") or "").strip()
    if not full_src:
        # 若你的数据把 formal_statement 与 proof 分开，这里自己拼
        fs = rec.get("formal_statement") or ""
        pf = rec.get("proof") or ""
        full_src = (fs.rstrip() + "\n" + pf.lstrip()).strip()

    # 切 header/主体（若 header 已在 rec.header，也没问题）
    h2, body = split_header_and_statement(full_src)
    if header and h2:  # 都有，以 rec.header 为准
        pass
    elif not header and h2:
        header = h2

    out = []
    for mode in modes:
        for t in range(per_mode):
            gb = gap_ratio
            if mode != "outline":
                # 做一些随机扰动：0.5 ~ 0.9
                gb = min(0.9, max(0.5, random.uniform(gap_ratio-0.1, gap_ratio+0.1)))
            sketch_body, num = apply_gaps(body, mode=mode, gap_ratio=gb, gap_token=gap_token)

            # 拼出 formal_statement（含 := by …），和 full_proof（gold）
            # 注意：训练时输入用 header + sketch_body；输出用 body（或仅 proof 体）
            rec_id = str(rec.get("id") or rec.get("name") or "unknown")
            out_rec = {
                "id": f"{rec_id}_{mode}_{t:02d}",
                "source_id": rec_id,
                "split": rec.get("split", ""),
                "header": header,
                "formal_statement": sketch_body.splitlines()[0] if sketch_body else "",
                "sketch": sketch_body,
                "full_proof": body,          # gold target（含完整 by 细节）
                "mode": mode,
                "num_gaps": int(num),
                "gap_style": gap_token,
            }
            out.append(out_rec)

            # 可选：把 .lean 落盘，方便抽检
            if dump_dir:
                pdir = Path(dump_dir) / mode
                pdir.mkdir(parents=True, exist_ok=True)
                (pdir / f"{out_rec['id']}.lean").write_text(
                    (header + "\n\n" + sketch_body + "\n"),
                    encoding="utf-8"
                )
                (pdir / f"{out_rec['id']}.gold.lean").write_text(
                    (header + "\n\n" + body + "\n"),
                    encoding="utf-8"
                )
    return out

# ------------- 主入口 -------------
def main(
    in_path="data.jsonl",
    out_path="sketch_train.jsonl",
    dump_dir=None,
    modes=("holes","mask-by","outline"),
    gap_ratio=0.7,
    per_mode=2,
    seed=7
):
    random.seed(seed)
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    if dump_dir:
        Path(dump_dir).mkdir(parents=True, exist_ok=True)

    total, written = 0, 0
    with jsonlines.open(out_path, "w") as w, jsonlines.open(in_path, "r") as r:
        for rec in r:
            total += 1
            # 只处理“已通过”的样本；你的 data.jsonl 若就是 PASS-only，可直接放行
            if rec.get("pass") is False:
                continue
            # 若来自 summary.jsonl，可把 attempts 里 pass==True 的每个样本展开
            if "attempts" in rec:
                for att in rec["attempts"]:
                    if att.get("pass") and att.get("lean_block"):
                        subrec = {**rec, "lean_block": att["lean_block"], "id": f"{rec.get('id')}_s{att.get('index',1):02d}"}
                        rows = build_sketch_record(subrec, modes, gap_ratio, per_mode, gap_token="<GAP>", dump_dir=dump_dir)
                        for rr in rows:
                            w.write(rr); written += 1
            else:
                rows = build_sketch_record(rec, modes, gap_ratio, per_mode, gap_token="<GAP>", dump_dir=dump_dir)
                for rr in rows:
                    w.write(rr); written += 1
    print(f"[DONE] read={total}, wrote={written} rows to {out_path}")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="in_path", default="data.jsonl")
    ap.add_argument("--out", dest="out_path", default="sketch_train.jsonl")
    ap.add_argument("--dump_dir", default=None)
    ap.add_argument("--modes", default="holes,mask-by,outline")
    ap.add_argument("--gap_ratio", type=float, default=0.7)
    ap.add_argument("--per_mode", type=int, default=2)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()
    main(args.in_path, args.out_path, args.dump_dir,
         tuple(m.strip() for m in args.modes.split(",")),
         args.gap_ratio, args.per_mode, args.seed)