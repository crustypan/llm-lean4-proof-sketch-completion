
# run_holewise_generate.py
import os, re, json, time, hashlib, subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from peft import PeftModel

try:
    from tqdm.auto import tqdm
except Exception:
    def tqdm(x, **kwargs):
        return x

EOFILL = "<eofill>"
HOLE = "<proof>"

SYSTEM_PROMPT = (
    "You are a Lean 4 proof completion model.\n"
    "Given a Lean 4 sketch that contains exactly ONE <proof> hole, you must output ONLY the Lean code "
    "that should replace the <proof>.\n"
    "Ignore any 'sorry' in the input; do not try to replace or modify it.\n"
    "Do not output explanations. Do not repeat the input.\n"
    "Do NOT include the token 'sorry' anywhere in your output.\n"
    "End your output with the token <eofill>.\n"
)

_CODEFENCE_RE = re.compile(r"^```.*?\n|\n```$", re.S)
_SORRY_RE = re.compile(r"\bsorry\b")

def resolve_adapter_dir(adapter_dir: str) -> str:
    """
    adapter_dir 可以是 checkpoint-xxx 或 out_dir 根目录。
    默认：如果设置 PREFER_CHECKPOINT=1 则优先最新 checkpoint；否则优先根目录（final adapter）。
    """
    p = Path(adapter_dir)

    cands = []
    for ck in p.glob("checkpoint-*"):
        if (ck / "adapter_config.json").exists():
            m = re.search(r"checkpoint-(\d+)", ck.name)
            step = int(m.group(1)) if m else -1
            cands.append((step, ck))
    cands.sort()

    prefer_ckpt = os.environ.get("PREFER_CHECKPOINT", "0") == "1"
    if prefer_ckpt and cands:
        return str(cands[-1][1])

    if (p / "adapter_config.json").exists():
        return str(p)

    if cands:
        return str(cands[-1][1])

    raise FileNotFoundError(f"adapter_config.json not found under: {p}")

def load_jsonl(path: str):
    items = []
    with open(path, "r", encoding="utf-8") as f:
        for ln in f:
            ln = ln.strip()
            if ln:
                items.append(json.loads(ln))
    return items

def clean_fill(text: str) -> str:
    t = text.strip()
    t = _CODEFENCE_RE.sub("", t).strip()
    if EOFILL in t:
        t = t.split(EOFILL, 1)[0]
    t = t.replace(HOLE, "").strip("\n")
    return t.rstrip()

def find_n_holes(s: str) -> int:
    return s.count(HOLE)

def mask_all_holes_except_i(sketch: str, keep_i: int, mask: str = "sorry") -> str:
    # 逐个 occurrence 替换，保持顺序
    out = []
    i = 0
    cnt = 0
    while True:
        pos = sketch.find(HOLE, i)
        if pos < 0:
            out.append(sketch[i:])
            break
        out.append(sketch[i:pos])
        out.append(HOLE if cnt == keep_i else mask)
        i = pos + len(HOLE)
        cnt += 1
    return "".join(out)

def find_first_hole_linecol(s: str):
    idx = s.find(HOLE)
    if idx < 0:
        return -1, -1
    line = s.count("\n", 0, idx)
    col = idx - (s.rfind("\n", 0, idx) + 1)
    return line, col

def insert_first_hole(sketch: str, fill: str) -> str:
    """
    把 fill 插入 sketch 的第一个 <proof>。
    - 支持独占一行洞
    - 支持行内洞
    - 多行 fill 时用括号包裹
    """
    if HOLE not in sketch:
        return sketch

    lines = sketch.splitlines()
    # 找洞所在行
    idx = sketch.find(HOLE)
    hole_line_idx = sketch.count("\n", 0, idx)
    if hole_line_idx < 0 or hole_line_idx >= len(lines):
        return sketch.replace(HOLE, fill, 1)

    ln = lines[hole_line_idx]
    pos = ln.find(HOLE)
    left = ln[:pos]
    right = ln[pos + len(HOLE):]

    fill = fill.rstrip("\n")
    fill_lines = fill.splitlines() if fill.strip() != "" else [""]

    # A: 独占一行
    if ln.strip() == HOLE:
        indent = len(ln) - len(ln.lstrip(" "))
        pref = " " * indent
        new_block = []
        for fl in fill_lines:
            if fl.strip() == "":
                new_block.append("")
            else:
                new_block.append(pref + fl)
        lines = lines[:hole_line_idx] + new_block + lines[hole_line_idx+1:]
        return "\n".join(lines)

    # B: 行内洞，单行替换
    if len(fill_lines) == 1:
        lines[hole_line_idx] = left + fill_lines[0] + right
        return "\n".join(lines)

    # C: 行内洞，多行：括号包裹
    line_indent = len(ln) - len(ln.lstrip(" "))
    cont_indent = " " * (line_indent + 2)

    lines[hole_line_idx] = left + "(" + fill_lines[0]

    mid = []
    for fl in fill_lines[1:-1]:
        if fl.strip() == "":
            mid.append("")
        else:
            mid.append(cont_indent + fl)

    last = fill_lines[-1]
    if last.strip() == "":
        mid.append(cont_indent + ")" + right)
    else:
        mid.append(cont_indent + last + ")" + right)

    lines = lines[:hole_line_idx+1] + mid + lines[hole_line_idx+1:]
    return "\n".join(lines)

def normalize_body_for_by(block: str) -> str:
    # 仅当 block 被当作 theorem ... := by 的后续 proof body 时使用
    out = []
    for ln in block.splitlines():
        if ln.strip() == "":
            out.append("")
        elif ln.startswith("  "):
            out.append(ln)
        else:
            out.append("  " + ln)
    return "\n".join(out)

def assemble_final_lean(header: str, theorem: str, cur: str) -> str:
    h = (header or "").strip()
    t = (theorem or "").strip()
    c = (cur or "").rstrip() + "\n"

    # 如果 cur 看起来已经包含 theorem/lemma/example，则认为它是完整文件
    if re.search(r"\b(theorem|lemma|example)\b", c):
        return (h + "\n\n" if h else "") + c

    body = normalize_body_for_by(cur)
    return (h + "\n\n" if h else "") + t + "\n" + body + "\n"

def build_prompt(tokenizer, header: str, theorem: str, sketch_one_hole: str) -> str:
    line, col = find_first_hole_linecol(sketch_one_hole)
    user = (
        "Replace the <proof> in the following Lean 4 sketch.\n"
        "Ignore any occurrences of 'sorry'.\n\n"
        "Do NOT include the token 'sorry' anywhere in your output.\n"
        "[HEADER]\n"
        f"{header}\n\n"
        "[THEOREM+SKETCH]\n"
        f"{theorem}\n"
        f"{sketch_state}\n"
    )
    msgs = [{"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user}]
    if getattr(tokenizer, "chat_template", None):
        return tokenizer.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
    return f"<<SYS>>\n{SYSTEM_PROMPT}\n<</SYS>>\n\n<<USER>>\n{user}\n<</USER>>\n\n<<ASSISTANT>>\n"

def _stable_int_seed(s: str) -> int:
    return int(hashlib.md5(s.encode("utf-8")).hexdigest(), 16) % (2**31 - 1)

def tail(s: str, n: int = 4000) -> str:
    return "" if s is None else s[-n:]

def contains_sorry(fill: str) -> bool:
    return bool(_SORRY_RE.search(fill))

def compile_one(code: str, lean_proj: str, lake_bin: str, out_dir: Path, key: str, timeout: int, cache: dict):
    # cache by sha1(code)
    h = hashlib.sha1(code.encode("utf-8")).hexdigest()
    if h in cache:
        return cache[h]

    out_path = out_dir / f"{key}.lean"
    out_path.write_text(code, encoding="utf-8")

    t0 = time.time()
    cmd = [lake_bin, "env", "lean", str(out_path)]
    try:
        p = subprocess.run(
            cmd,
            cwd=lean_proj,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=os.environ.copy(),
        )
        ok = (p.returncode == 0)
        res = {
            "pass": ok,
            "returncode": p.returncode,
            "time_sec": time.time() - t0,
            "lean_path": str(out_path),
            "stdout_tail": tail(p.stdout),
            "stderr_tail": tail(p.stderr),
            "tag": "pass" if ok else "lean_error",
        }
    except subprocess.TimeoutExpired as e:
        res = {
            "pass": False,
            "returncode": None,
            "time_sec": time.time() - t0,
            "lean_path": str(out_path),
            "stdout_tail": tail(getattr(e, "stdout", "")),
            "stderr_tail": tail(getattr(e, "stderr", "")),
            "tag": "timeout",
        }
    except Exception as e:
        res = {
            "pass": False,
            "returncode": None,
            "time_sec": time.time() - t0,
            "lean_path": str(out_path),
            "stdout_tail": "",
            "stderr_tail": repr(e),
            "tag": "other",
        }

    cache[h] = res
    return res

def generate_k_fills(tokenizer, model, prompt: str, k: int, max_new: int, temperature: float, top_p: float, stop_id: int, seed: int, chunk: int = 8):
    # 分 chunk 采样，避免一次性 num_return_sequences 太大/显存抖动
    fills = []
    enc = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=int(os.environ.get("MAX_LEN", "8192")))
    input_ids0 = enc["input_ids"].to(model.device)
    attn0 = enc["attention_mask"].to(model.device)
    in_len = input_ids0.shape[-1]

    left = k
    t = 0
    while left > 0:
        bs = min(chunk, left)
        torch.manual_seed((seed + t) % (2**31 - 1))
        torch.cuda.manual_seed_all((seed + t) % (2**31 - 1))
        t += 1

        input_ids = input_ids0.repeat(bs, 1)
        attn = attn0.repeat(bs, 1)

        with torch.no_grad():
            gen = model.generate(
                input_ids=input_ids,
                attention_mask=attn,
                max_new_tokens=max_new,
                do_sample=True,
                temperature=temperature,
                top_p=top_p,
                eos_token_id=stop_id,
                pad_token_id=tokenizer.pad_token_id,
            )

        # gen: [bs, in_len+new]
        for r in range(bs):
            out_text = tokenizer.decode(gen[r][in_len:], skip_special_tokens=False)
            fill = clean_fill(out_text)
            fills.append({"raw": out_text, "fill": fill})
        left -= bs

    return fills

def main():
    cfg_path    = os.environ["RUN_CONFIG_PATH"]
    sketch_jsonl = os.environ["SKETCH_JSONL"]
    out_jsonl   = os.environ["OUT_JSONL"]

    adapter_dir   = os.environ.get("ADAPTER_DIR", "")
    tokenizer_dir = os.environ.get("TOKENIZER_DIR", "")

    # 每洞一次性采样 k 个
    k_cand = int(os.environ.get("K_CAND_PER_HOLE", "32"))
    max_new = int(os.environ.get("MAX_NEW_TOKENS_PER_HOLE", "256"))
    temperature = float(os.environ.get("TEMPERATURE", "0.7"))
    top_p = float(os.environ.get("TOP_P", "0.95"))

    # 洞内编译筛选
    lean_proj = os.environ["LEAN_PROJ"]
    lake_bin  = os.environ.get("LAKE", "lake")
    cand_timeout = int(os.environ.get("CAND_TIMEOUT", "120"))   # 单个候选的 lean 超时（洞内筛选用，建议比最终验证短）
    cand_jobs    = int(os.environ.get("CAND_JOBS", "2"))

    # 组合输出完整证明的上限（防止爆炸）
    max_full_per_ex = int(os.environ.get("MAX_FULL_PROOFS_PER_EX", "8"))
    max_keep_per_hole_for_combo = int(os.environ.get("MAX_KEEP_PER_HOLE_FOR_COMBO", "3"))

    # seed
    seed_base = int(os.environ.get("GEN_SEED_BASE", "1234"))

    rank = int(os.environ.get("RANK", "0"))
    world = int(os.environ.get("WORLD_SIZE", "1"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    torch.cuda.set_device(local_rank)

    cfg = json.loads(Path(cfg_path).read_text(encoding="utf-8"))
    base_model = cfg["base_model"]
    out_dir_root = cfg.get("out_dir", "")

    if not adapter_dir:
        adapter_dir = out_dir_root
    adapter_dir = resolve_adapter_dir(adapter_dir)

    if not tokenizer_dir:
        tokenizer_dir = out_dir_root

    outp = Path(out_jsonl)
    # 推荐传目录：OUT_JSONL=/path/to/gen_dir
    if outp.suffix == ".jsonl":
        out_file = outp
        out_file.parent.mkdir(parents=True, exist_ok=True)
        lean_files_dir = out_file.parent / f"lean_files_rank{rank}"
    else:
        outp.mkdir(parents=True, exist_ok=True)
        out_file = outp / f"full_rank{rank}.jsonl"
        lean_files_dir = outp / f"lean_files_rank{rank}"
    lean_files_dir.mkdir(parents=True, exist_ok=True)

    if rank == 0:
        print("base_model:", base_model)
        print("tokenizer_dir:", tokenizer_dir)
        print("adapter_dir:", adapter_dir)
        print("out_file:", out_file)
        print("k_cand:", k_cand, "cand_jobs:", cand_jobs, "cand_timeout:", cand_timeout)
        print("max_full_per_ex:", max_full_per_ex, "max_keep_per_hole_for_combo:", max_keep_per_hole_for_combo)

    tokenizer = AutoTokenizer.from_pretrained(tokenizer_dir, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.add_special_tokens({"additional_special_tokens": [HOLE, EOFILL]})
    tokenizer.truncation_side = "right"
    tokenizer.padding_side = "left"

    eofill_id = tokenizer.convert_tokens_to_ids(EOFILL)
    stop_id = eofill_id if (eofill_id is not None and eofill_id >= 0) else tokenizer.eos_token_id

    bnb_cfg = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True,
        bnb_4bit_compute_dtype=torch.bfloat16,
    )
    model = AutoModelForCausalLM.from_pretrained(
        base_model,
        quantization_config=bnb_cfg,
        device_map={"": local_rank},
        torch_dtype=torch.bfloat16,
    )
    model.resize_token_embeddings(len(tokenizer))
    model = PeftModel.from_pretrained(model, adapter_dir, is_trainable=False)
    model.eval()

    data = load_jsonl(sketch_jsonl)
    # split 处理
    if any(("split" in x) for x in data):
        test = [x for x in data if x.get("split") == "test"] or [x for x in data if x.get("split") == "valid"] or data
    else:
        test = data
    test = test[rank::world]

    compile_cache = {}  # sha1(code)->res

    t0 = time.time()
    wrote = 0
    with open(out_file, "w", encoding="utf-8") as w:
        pbar = tqdm(
            test,
            total=len(test),
            desc=f"[gen] rank{rank}",
            position=rank,         # ✅ 多进程各占一行
            leave=True,
            dynamic_ncols = True,
            mininterval = float(os.environ.get("TQDM_MININTERVAL", "60")),         # ✅ 至少每 k 秒才刷新一次（默认 0.1s）
            maxinterval = float(os.environ.get("TQDM_MAXINTERVAL", "180")),   # ✅ 最久 k 秒至少刷新一次（防止太久没动静）
            miniters = int(os.environ.get("TQDM_MINITERS", "1")),  
            smoothing = float(os.environ.get("TQDM_SMOOTHING", "0.0")),
        )
        for ex in pbar:
            rid = ex.get("id", "")
            header = ex.get("header", "") or ""
            theorem = ex.get("theorem", "") or ""
            sketch = ex.get("sketch", "") or ex.get("proof", "") or ""
            if not sketch:
                # 没有可用 sketch，直接跳过
                rec = dict(ex)
                rec.update({
                    "holewise_pass": False,
                    "fail_reason": "no_sketch",
                    "num_holes": None,
                    "hole_debug": [],
                    "hole_cand_records": [],
                })
                w.write(json.dumps(rec, ensure_ascii=False) + "\n")
                wrote += 1
                
                # 更新进度条右侧信息
                pbar.set_postfix_str(f"id={rid} no_sketch wrote={wrote}", refresh=False)
                continue

            H = find_n_holes(sketch)
            
            # ✅ 更新进度条右侧信息（样本级）
            pbar.set_postfix_str(f"id={rid} holes={H} wrote={wrote}", refresh=False)
            
            
            if H == 0:
                # 无洞：当作已完成证明，直接输出一条 full proof
                full_code = assemble_final_lean(header, theorem, sketch)
                rec = dict(ex)
                rec.update({
                    "holewise_pass": True,
                    "num_holes": 0,
                    "full_uid": f"{rid}__full00",
                    "gen_case_key": f"{rid}__full00__r{rank}",
                    "lean_code": full_code,
                    "hole_ok_fills": [],
                    "hole_choice": [],
                    "hole_cand_records": [],
                    "hole_debug": [],
                })
                w.write(json.dumps(rec, ensure_ascii=False) + "\n")
                wrote += 1
                
                pbar.set_postfix_str(f"id={rid} holes=0 wrote={wrote}", refresh=False)

                continue


            hole_ok_fills = []
            hole_debug = []
            hole_cand_records_all = []   # 保存每个洞的 k 条候选的状态/失败原因/第几条生成
            holewise_pass = True
            fail_reason = None
            fail_hole = None
            

            # 逐洞处理
            for hi in range(H):
            
                #  仅偶尔刷新 postfix，避免刷屏
                if hi == 0 or (hi + 1) % 5 == 0 or hi == H - 1:
                    pbar.set_postfix_str(
                        f"id={rid} hole={hi+1}/{H} wrote={wrote}",
                        refresh=False
                    )
                masked = mask_all_holes_except_i(sketch, hi, mask="sorry")
                prompt = build_prompt(tokenizer, header, theorem, masked)

                seed = (seed_base + _stable_int_seed(f"{rid}__hole{hi}")) % (2**31 - 1)
                
                # ===== 新增：保存每个洞的 k 条候选的状态与失败原因 =====
                # hole_cand_records_all: 外层按洞累积
                # （放在洞循环外初始化：hole_cand_records_all = []）
                cand_pack = generate_k_fills(
                    tokenizer, model, prompt,
                    k=k_cand, max_new=max_new,
                    temperature=temperature, top_p=top_p,
                    stop_id=stop_id, seed=seed,
                    chunk=int(os.environ.get("GEN_CHUNK", "8")),
                )

                # cand_records: 每条生成候选的记录（长度 k_cand）
                cand_records = []
                seen = set()
                to_compile = []   # 存放 (cand_rec)；cand_rec 中含 fill/cand_index/k_gen_rank

                for k_idx, c in enumerate(cand_pack):
                    fill = (c["fill"] or "").strip()

                    rec = {
                        "k_gen_rank": k_idx + 1,   # ✅ 1-based：第几条生成
                        "fill": fill,
                        "status": None,
                        "fail_reason": None,
                        # "cand_index": ...（进入编译队列才加）
                    }

                    if not fill:
                        rec["status"] = "fail"
                        rec["fail_reason"] = "empty"
                        cand_records.append(rec)
                        continue

                    if contains_sorry(fill):
                        rec["status"] = "fail"
                        rec["fail_reason"] = "includ sorry"   # ✅ 按你要求的字符串
                        cand_records.append(rec)
                        continue

                    if fill in seen:
                        rec["status"] = "fail"
                        rec["fail_reason"] = "duplicate"
                        cand_records.append(rec)
                        continue

                    seen.add(fill)
                    rec["cand_index"] = len(to_compile)  # ✅ 去重后进入编译队列的编号
                    rec["status"] = "to_compile"
                    to_compile.append(rec)
                    cand_records.append(rec)

                # 若过滤后没有任何可编译候选：该洞失败
                if not to_compile:
                    holewise_pass = False
                    fail_reason = "no_candidate_after_filter"
                    fail_hole = hi
                    hole_debug.append({
                        "hole": hi, "status": "fail",
                        "reason": "all_empty_or_contains_sorry_or_dup",
                        "num_raw": len(cand_pack),
                        "num_to_compile": 0,
                        "num_ok": 0,
                    })
                    # ✅ 把该洞的候选记录也保存下来
                    hole_cand_records_all.append(cand_records)
                    break

                # ===== 编译筛选：给每条候选写明失败原因（lean_error/timeout/other） =====
                ok_fills = []

                def one_job(rec):
                    fill = rec["fill"]
                    masked_filled = insert_first_hole(masked, fill)
                    code = assemble_final_lean(header, theorem, masked_filled)
                    key = f"{rid}__h{hi:03d}__c{rec['cand_index']:03d}__r{rank}"
                    res = compile_one(code, lean_proj, lake_bin, lean_files_dir, key, cand_timeout, compile_cache)
                    return rec, res

                with ThreadPoolExecutor(max_workers=cand_jobs) as pool:
                    futs = [pool.submit(one_job, rec) for rec in to_compile]
                    for fut in as_completed(futs):
                        rec, res = fut.result()
                        if res.get("pass"):
                            # ✅ 正确 fill：记录它是 k 次生成的第几条
                            ok_fills.append({
                                "cand_index": rec["cand_index"],
                                "k_gen_rank": rec["k_gen_rank"],
                                "fill": rec["fill"],
                                "time_sec": res.get("time_sec"),
                            })
                            rec["status"] = "ok"
                            rec["fail_reason"] = None
                        else:
                            rec["status"] = "fail"
                            rec["fail_reason"] = res.get("tag", "other")  # lean_error/timeout/other

                # 稳定排序
                ok_fills.sort(key=lambda x: x["cand_index"])

                # 洞内全灭：该题失败
                if not ok_fills:
                    holewise_pass = False
                    fail_reason = "all_candidates_fail_compile"
                    fail_hole = hi
                    hole_debug.append({
                        "hole": hi, "status": "fail",
                        "reason": "compile_all_failed",
                        "num_raw": len(cand_pack),
                        "num_to_compile": len(to_compile),
                        "num_ok": 0,
                    })
                    # ✅ 保存该洞候选结果
                    hole_cand_records_all.append(cand_records)
                    break

                # ✅ 洞成功：保存洞候选结果 + 洞正确 fill 列表
                hole_ok_fills.append(ok_fills)

                hole_debug.append({
                    "hole": hi, "status": "pass",
                    "num_raw": len(cand_pack),
                    "num_to_compile": len(to_compile),
                    "num_ok": len(ok_fills),
                })

                hole_cand_records_all.append(cand_records)


            if not holewise_pass:
                rec = dict(ex)
                rec.update({
                    "holewise_pass": False,
                    "num_holes": H,
                    "fail_hole": fail_hole,
                    "fail_reason": fail_reason,
                    "hole_debug": hole_debug,
                    "hole_cand_records": hole_cand_records_all,

                })
                w.write(json.dumps(rec, ensure_ascii=False) + "\n")
                wrote += 1
                continue

            # 组合出 1..M 条完整证明
            # 每洞最多取前 max_keep_per_hole_for_combo 个 ok fills
            per_hole_fills = []
            for hi in range(H):
                per_hole_fills.append([x["fill"] for x in hole_ok_fills[hi][:max_keep_per_hole_for_combo]])

            # BFS 组合，限制 max_full_per_ex
            states = [(sketch, [])]  # (sketch_state_with_holes, choice_indices)
            for hi in range(H):
                new_states = []
                choices = per_hole_fills[hi]
                for st, idxs in states:
                    for cj, fill in enumerate(choices):
                        st2 = insert_first_hole(st, fill)
                        new_states.append((st2, idxs + [cj]))
                        if len(new_states) >= max_full_per_ex:
                            break
                    if len(new_states) >= max_full_per_ex:
                        break
                states = new_states
                if not states:
                    break

            # 输出每条完整证明为一行（便于最终 verify）
            for pi, (filled_sketch, choice) in enumerate(states):
                full_code = assemble_final_lean(header, theorem, filled_sketch)
                full_uid = f"{rid}__full{pi:02d}"
                rec = dict(ex)
                rec.update({
                    "holewise_pass": True,
                    "num_holes": H,
                    "hole_debug": hole_debug,
                    "hole_cand_records": hole_cand_records_all,


                    # 每条 full proof 独立 id
                    "full_uid": full_uid,
                    "gen_case_key": f"{full_uid}__r{rank}",

                    # 洞级可编译候选（用于复现/分析）
                    "hole_ok_fills": hole_ok_fills,   # 每洞若干 {cand_index, fill, time_sec}
                    "hole_choice": choice,            # 组合时每洞选了第几个（在截断后的 per_hole_fills 内）
                    "lean_code": full_code,           # 最终给 verify 用
                    
                })
                w.write(json.dumps(rec, ensure_ascii=False) + "\n")
                wrote += 1

    if rank == 0:
        print(f"done. wrote={wrote} lines. elapsed={time.time()-t0:.1f}s")

if __name__ == "__main__":
    main()
