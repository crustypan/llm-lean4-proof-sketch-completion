#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
report_eval.py

Usage examples:
  python report_eval.py --verify_jsonl /path/to/verify.jsonl

  # join meta info by id (e.g., gen.jsonl that contains name/source_id/sample_index)
  python report_eval.py --verify_jsonl /path/to/verify.jsonl --meta_jsonl /path/to/gen.jsonl

  # dump snippets around error locations
  python report_eval.py --verify_jsonl /path/to/verify.jsonl --dump_snippets_dir /path/to/snips --snippet_radius 3

Output:
  - prints summary to stdout
  - writes:
      out_dir/summary.json
      out_dir/fails.csv
      out_dir/top_errors.txt
      out_dir/by_name.csv (if meta_jsonl has name)
      out_dir/by_source.csv (if meta_jsonl has source_id)
"""

import argparse, json, os, re, csv, math
from pathlib import Path
from collections import Counter, defaultdict
from statistics import median

# ---------- JSONL helpers ----------

def read_jsonl(path: str):
    items = []
    p = Path(path)
    with p.open("r", encoding="utf-8") as f:
        for ln in f:
            ln = ln.strip()
            if not ln:
                continue
            items.append(json.loads(ln))
    return items

def build_meta_index(meta_jsonl: str, key_field: str = "id"):
    """
    Build mapping: id -> meta record
    meta_jsonl can be raw dataset or gen jsonl; we only keep a few fields if exist.
    """
    idx = {}
    if not meta_jsonl:
        return idx

    for r in read_jsonl(meta_jsonl):
        rid = r.get(key_field)
        if rid is None:
            continue
        rid = str(rid)
        # keep whole record (or you can prune here)
        idx[rid] = r
    return idx

# ---------- error extraction ----------

# match a standard Lean error line with file:line:col: error: ...
ERR_LINE_RE = re.compile(r"^(.*?\.lean):(\d+):(\d+):\s+error:\s+(.*)$", re.M)
# sometimes no file prefix: "error: ..."
ERR_NOFILE_RE = re.compile(r"^error:\s+(.*)$", re.M)

def extract_first_error(stdout_tail: str, stderr_tail: str):
    """
    Return dict with:
      first_error_line: original full line (best effort)
      lean_file, line, col, msg
    """
    blob = ""
    if stdout_tail:
        blob += stdout_tail + "\n"
    if stderr_tail:
        blob += stderr_tail + "\n"
    blob = blob.strip()
    if not blob:
        return {
            "first_error_line": "",
            "lean_file": None,
            "line": None,
            "col": None,
            "msg": "",
        }

    m = ERR_LINE_RE.search(blob)
    if m:
        lean_file, line, col, msg = m.group(1), int(m.group(2)), int(m.group(3)), m.group(4).strip()
        first_line = f"{lean_file}:{line}:{col}: error: {msg}"
        return {
            "first_error_line": first_line,
            "lean_file": lean_file,
            "line": line,
            "col": col,
            "msg": msg,
        }

    # fallback: find "error: ..."
    m2 = ERR_NOFILE_RE.search(blob)
    if m2:
        msg = m2.group(1).strip()
        first_line = f"error: {msg}"
        return {
            "first_error_line": first_line,
            "lean_file": None,
            "line": None,
            "col": None,
            "msg": msg,
        }

    # fallback: take first non-empty line
    first = next((x for x in blob.splitlines() if x.strip()), "")
    return {
        "first_error_line": first.strip(),
        "lean_file": None,
        "line": None,
        "col": None,
        "msg": first.strip(),
    }

def normalize_error_message(msg: str) -> str:
    """
    Normalize msg for counting Top errors.
    - strip excessive spaces
    - truncate long lines
    """
    if msg is None:
        return ""
    t = " ".join(msg.strip().split())
    if len(t) > 220:
        t = t[:220] + "..."
    return t

def infer_tag_from_blob(blob: str) -> str:
    """
    Infer coarse tag from stdout/stderr content.
    (If you already have your own tag in verify jsonl, we keep that; this is for fallback.)
    """
    if not blob:
        return "unknown"

    b = blob

    # order matters
    if "timeout" in b.lower():
        return "timeout"
    if "unsolved goals" in b:
        return "unsolved_goals"
    if "unexpected token" in b or "unexpected identifier" in b or "expected ']'" in b or "expected ')'" in b:
        return "syntax_error"
    if "type mismatch" in b or "application type mismatch" in b:
        return "type_mismatch"
    if "failed to synthesize" in b or "typeclass" in b or "instance" in b and "failed" in b:
        return "typeclass_failure"

    # common tactic failures
    if "failed" in b and "tactic" in b:
        return "tactic_fail"
    if "linarith failed" in b or "nlinarith failed" in b:
        return "tactic_fail"
    if "rewrite" in b and "failed" in b:
        return "tactic_fail"
    if "simp" in b and "failed" in b:
        return "tactic_fail"
    if "interval_cases failed" in b:
        return "tactic_fail"

    # non-zero return code but not categorized
    return "other_rc1"

def coarse_category_from_msg(msg: str) -> str:
    """
    A more user-friendly category bucket from first error msg.
    """
    m = (msg or "").lower()

    if "unexpected token" in m or "expected ']'" in m or "expected ')'" in m or "unexpected identifier" in m:
        return "syntax"
    if "unsolved goals" in m:
        return "unsolved_goals"
    if "unknown identifier" in m:
        return "unknown_id"
    if "type mismatch" in m:
        return "type_mismatch"
    if "failed to synthesize" in m or "typeclass" in m:
        return "typeclass"
    if "interval_cases failed" in m:
        return "interval_cases_fail"
    if "linarith failed" in m or "nlinarith failed" in m:
        return "linarith_fail"
    if "rewrite" in m and "failed" in m:
        return "rewrite_fail"
    if "simp" in m and "failed" in m:
        return "simp_fail"
    if "no goals to be solved" in m:
        return "no_goals"
    if "timeout" in m:
        return "timeout"
    if "error" in m:
        return "other_error"
    return "other"

# ---------- stats helpers ----------

def percentile(xs, p):
    if not xs:
        return None
    xs2 = sorted(xs)
    k = (len(xs2) - 1) * (p / 100.0)
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return xs2[int(k)]
    d0 = xs2[f] * (c - k)
    d1 = xs2[c] * (k - f)
    return d0 + d1

def safe_float(x, default=None):
    try:
        return float(x)
    except Exception:
        return default

# ---------- snippet dumping ----------

def read_lines_around(path: str, line: int, radius: int = 3):
    """
    Read line±radius around a 1-based line number.
    """
    p = Path(path)
    if not p.exists():
        return None
    lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    if line is None:
        return None
    i = max(1, int(line))
    lo = max(1, i - radius)
    hi = min(len(lines), i + radius)
    out = []
    for ln in range(lo, hi + 1):
        prefix = ">> " if ln == i else "   "
        out.append(f"{prefix}{ln:4d}: {lines[ln-1]}")
    return "\n".join(out)

# ---------- main report ----------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--verify_jsonl", required=True, help="verify result jsonl from run_lean_verify.py")
    ap.add_argument("--meta_jsonl", default="", help="optional meta jsonl (id/name/source_id/...) to join")
    ap.add_argument("--out_dir", default="", help="output directory (default: <verify_jsonl_parent>/report)")
    ap.add_argument("--topk", type=int, default=20, help="Top-K errors to show")
    ap.add_argument("--examples_per_tag", type=int, default=5, help="examples to print per category/tag")

    ap.add_argument("--dump_snippets_dir", default="", help="if set, dump fail snippets to this dir")
    ap.add_argument("--snippet_radius", type=int, default=3, help="context lines around error line")

    args = ap.parse_args()

    verify_path = Path(args.verify_jsonl)
    assert verify_path.exists(), f"verify_jsonl not found: {verify_path}"

    out_dir = Path(args.out_dir) if args.out_dir else (verify_path.parent / "report")
    out_dir.mkdir(parents=True, exist_ok=True)

    meta_idx = build_meta_index(args.meta_jsonl) if args.meta_jsonl else {}

    rows = read_jsonl(str(verify_path))

    # enrich rows
    enriched = []
    time_list = []
    for r in rows:
        rid = str(r.get("id", ""))

        stdout_tail = r.get("stdout_tail", "") or ""
        stderr_tail = r.get("stderr_tail", "") or ""
        blob = (stdout_tail + "\n" + stderr_tail).strip()

        fe = extract_first_error(stdout_tail, stderr_tail)
        first_msg = fe["msg"]
        first_norm = normalize_error_message(first_msg)

        raw_tag = r.get("tag", "") or ""
        # If your verifier tag is too coarse (e.g., "lean_error"), you can still use inferred_tag for analysis.
        inferred_tag = infer_tag_from_blob(blob)
        category = coarse_category_from_msg(first_msg)

        # pass
        ok = bool(r.get("pass", False))

        t = safe_float(r.get("time_sec", None), None)
        if t is not None:
            time_list.append(t)

        meta = meta_idx.get(rid, {})
        name = meta.get("name", r.get("name", "")) or ""
        source_id = meta.get("source_id", r.get("source_id", None))
        sample_index = meta.get("sample_index", r.get("sample_index", None))

        enriched.append({
            **r,
            "id": rid,
            "raw_tag": raw_tag,
            "inferred_tag": inferred_tag,
            "category": category,
            "first_error_line": fe["first_error_line"],
            "first_error_msg": first_msg,
            "first_error_norm": first_norm,
            "err_file": fe["lean_file"],
            "err_line": fe["line"],
            "err_col": fe["col"],
            "name": name,
            "source_id": source_id,
            "sample_index": sample_index,
        })

    total = len(enriched)
    passed = sum(1 for x in enriched if x.get("pass"))
    failed = total - passed
    pass_rate = (passed / total * 100.0) if total else 0.0

    raw_tag_cnt = Counter(x.get("raw_tag","") for x in enriched if not x.get("pass"))
    inf_tag_cnt = Counter(x.get("inferred_tag","") for x in enriched if not x.get("pass"))
    cat_cnt = Counter(x.get("category","") for x in enriched if not x.get("pass"))

    top_errors = Counter(x.get("first_error_norm","") for x in enriched if (not x.get("pass") and x.get("first_error_norm")))

    # time stats
    t_stats = {}
    if time_list:
        t_stats = {
            "min": min(time_list),
            "median": median(time_list),
            "p90": percentile(time_list, 90),
            "p95": percentile(time_list, 95),
            "p99": percentile(time_list, 99),
            "max": max(time_list),
        }

    # ---------- print summary ----------
    print("\n" + "="*80)
    print("Eval Summary")
    print("="*80)
    print(f"verify_jsonl: {verify_path}")
    if args.meta_jsonl:
        print(f"meta_jsonl:   {args.meta_jsonl}")
    print(f"total: {total}")
    print(f"PASS:  {passed}/{total} = {pass_rate:.2f}%")
    print(f"FAIL:  {failed}")
    if t_stats:
        print("time_sec stats:", {k: round(v, 3) for k,v in t_stats.items()})

    print("\n[FAIL raw_tag counts] (from verify jsonl)")
    for k,v in raw_tag_cnt.most_common(30):
        print(f"  {k or '<empty>'}: {v}")

    print("\n[FAIL inferred_tag counts] (from stdout/stderr regex)")
    for k,v in inf_tag_cnt.most_common(30):
        print(f"  {k}: {v}")

    print("\n[FAIL category buckets] (from first_error msg)")
    for k,v in cat_cnt.most_common(30):
        print(f"  {k}: {v}")

    print(f"\n[Top first_error msgs] top={args.topk}")
    for msg,c in top_errors.most_common(args.topk):
        print(f"  {c:4d}  {msg}")

    # examples per category
    print("\n[Examples per category]")
    for cat, _ in cat_cnt.most_common():
        exs = [x for x in enriched if (not x.get("pass") and x.get("category")==cat)]
        if not exs:
            continue
        print(f"\n-- category={cat} n={len(exs)} --")
        for x in exs[:args.examples_per_tag]:
            print(f"id={x['id']}  raw_tag={x.get('raw_tag','')}  inferred={x.get('inferred_tag','')}")
            if x.get("name"):
                print(f"  name={x['name']}")
            print(f"  first_error={x.get('first_error_line','')}")
            print(f"  lean_path={x.get('lean_path','')}")
            print("")

    # ---------- by_name / by_source ----------
    by_name = None
    if any(x.get("name") for x in enriched):
        g = defaultdict(list)
        for x in enriched:
            nm = x.get("name") or ""
            if nm:
                g[nm].append(x)
        by_name = []
        for nm, xs in g.items():
            tot = len(xs)
            pas = sum(1 for z in xs if z.get("pass"))
            by_name.append((nm, tot, pas, (pas/tot*100.0 if tot else 0.0)))
        by_name.sort(key=lambda t: (t[3], -t[1]))  # low passrate first, then larger groups
        # write csv
        out_csv = out_dir / "by_name.csv"
        with out_csv.open("w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["name", "n_samples", "n_pass", "pass_rate"])
            for nm, tot, pas, pr in by_name:
                w.writerow([nm, tot, pas, f"{pr:.2f}"])
        print(f"\n[Wrote] {out_csv}")

    by_source = None
    if any(x.get("source_id") is not None for x in enriched):
        g = defaultdict(list)
        for x in enriched:
            sid = x.get("source_id")
            if sid is not None:
                g[str(sid)].append(x)
        by_source = []
        for sid, xs in g.items():
            tot = len(xs)
            pas = sum(1 for z in xs if z.get("pass"))
            by_source.append((sid, tot, pas, (pas/tot*100.0 if tot else 0.0)))
        by_source.sort(key=lambda t: (t[3], -t[1]))
        out_csv = out_dir / "by_source.csv"
        with out_csv.open("w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["source_id", "n_samples", "n_pass", "pass_rate"])
            for sid, tot, pas, pr in by_source:
                w.writerow([sid, tot, pas, f"{pr:.2f}"])
        print(f"[Wrote] {out_csv}")

    # ---------- write fails.csv ----------
    fails_csv = out_dir / "fails.csv"
    with fails_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow([
            "id","name","source_id","sample_index",
            "raw_tag","inferred_tag","category",
            "time_sec","lean_path",
            "first_error_line","first_error_norm"
        ])
        for x in enriched:
            if x.get("pass"):
                continue
            w.writerow([
                x.get("id",""),
                x.get("name",""),
                x.get("source_id",""),
                x.get("sample_index",""),
                x.get("raw_tag",""),
                x.get("inferred_tag",""),
                x.get("category",""),
                x.get("time_sec",""),
                x.get("lean_path",""),
                x.get("first_error_line",""),
                x.get("first_error_norm",""),
            ])
    print(f"[Wrote] {fails_csv}")

    # ---------- write top_errors.txt ----------
    top_txt = out_dir / "top_errors.txt"
    with top_txt.open("w", encoding="utf-8") as f:
        f.write(f"Top first_error msgs (top={args.topk})\n\n")
        for msg,c in top_errors.most_common(args.topk):
            f.write(f"{c:4d}  {msg}\n")
    print(f"[Wrote] {top_txt}")

    # ---------- write summary.json ----------
    summary = {
        "verify_jsonl": str(verify_path),
        "meta_jsonl": args.meta_jsonl or "",
        "total": total,
        "passed": passed,
        "failed": failed,
        "pass_rate": pass_rate,
        "time_sec_stats": t_stats,
        "fail_raw_tag_counts": dict(raw_tag_cnt),
        "fail_inferred_tag_counts": dict(inf_tag_cnt),
        "fail_category_counts": dict(cat_cnt),
        "top_first_error": top_errors.most_common(args.topk),
    }
    (out_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[Wrote] {out_dir/'summary.json'}")

    # ---------- dump snippets ----------
    if args.dump_snippets_dir:
        snip_dir = Path(args.dump_snippets_dir)
        snip_dir.mkdir(parents=True, exist_ok=True)
        n_dump = 0
        for x in enriched:
            if x.get("pass"):
                continue
            lp = x.get("lean_path","")
            if not lp:
                continue

            # prefer err_file from parsing; fallback to lean_path
            err_file = x.get("err_file") or lp
            err_line = x.get("err_line")
            if err_line is None:
                # try parse from lean_path-prefixed first_error_line
                # already done in extract_first_error; if still None, skip snippet
                continue

            snippet = read_lines_around(err_file, err_line, radius=args.snippet_radius)
            if snippet is None:
                continue

            outp = snip_dir / f"{x['id']}.txt"
            with outp.open("w", encoding="utf-8") as f:
                f.write(f"id: {x['id']}\n")
                if x.get("name"):
                    f.write(f"name: {x['name']}\n")
                f.write(f"lean_path: {lp}\n")
                f.write(f"first_error: {x.get('first_error_line','')}\n\n")
                f.write(snippet + "\n")
            n_dump += 1
        print(f"[Dumped snippets] n={n_dump} -> {snip_dir}")

    print("\nDone. Report dir:", out_dir)

if __name__ == "__main__":
    main()
