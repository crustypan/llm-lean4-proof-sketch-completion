
# run_stepwise_generate.py
import os, re, json, time, hashlib
from pathlib import Path

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from peft import PeftModel

EOFILL = "<eofill>"
HOLE = "<proof>"

SYSTEM_PROMPT = (
    "You are a Lean 4 proof completion model.\n"
    "Given a Lean 4 sketch with one or more <proof> holes, output ONLY the Lean code "
    "that should replace the LAST <proof>.\n"
    "Do not output explanations. Do not repeat the input.\n"
    "End your output with the token <eofill>.\n"
)

def resolve_adapter_dir(adapter_dir: str) -> str:
    """adapter_dir 可以是 checkpoint-xxx 或 out_dir 根目录（自动挑最新 checkpoint）"""
    p = Path(adapter_dir)
    if (p / "adapter_config.json").exists():
        return str(p)
    cands = []
    for ck in p.glob("checkpoint-*"):
        if (ck / "adapter_config.json").exists():
            m = re.search(r"checkpoint-(\d+)", ck.name)
            step = int(m.group(1)) if m else -1
            cands.append((step, ck))
    if cands:
        cands.sort()
        return str(cands[-1][1])
    raise FileNotFoundError(f"adapter_config.json not found under: {p}")

def load_jsonl(path: str):
    items = []
    with open(path, "r", encoding="utf-8") as f:
        for ln in f:
            ln = ln.strip()
            if not ln:
                continue
            items.append(json.loads(ln))
    return items

def normalize_body_for_by(block: str) -> str:
    """保证 theorem ... := by 后面的 proof body 每行至少缩进 2 空格"""
    out = []
    for ln in block.splitlines():
        if ln.strip() == "":
            out.append("")
        elif ln.startswith("  "):
            out.append(ln)
        else:
            out.append("  " + ln)
    return "\n".join(out)

_CODEFENCE_RE = re.compile(r"^```.*?\n|\n```$", re.S)

def clean_fill(text: str) -> str:
    t = text.strip()
    t = _CODEFENCE_RE.sub("", t).strip()
    if EOFILL in t:
        t = t.split(EOFILL, 1)[0]
    t = t.replace(HOLE, "").strip("\n")
    return t.rstrip()

def _unbalanced(s: str) -> bool:
    return (s.count('[') > s.count(']')) or (s.count('(') > s.count(')')) or (s.count('{') > s.count('}'))

def _looks_truncated_lean(fill: str) -> bool:
    t = fill.rstrip()
    if t.endswith('[') or t.endswith(',') or t.endswith(':=') or t.endswith('by') or t.endswith('rw') or t.endswith('simp'):
        return True
    if 'rw [' in t and t.count('[') > t.count(']'):
        return True
    if 'linarith [' in t and t.count('[') > t.count(']'):
        return True
    return _unbalanced(t)



def find_last_hole_linecol(s: str):
    idx = s.rfind(HOLE)
    if idx < 0:
        return -1, -1
    line = s.count("\n", 0, idx)
    col = idx - (s.rfind("\n", 0, idx) + 1)
    return line, col

def insert_last_hole(sketch: str, fill: str) -> str:
    """把 fill 插入 sketch 的最后一个 <proof>，尽量保持缩进；支持行内洞（simp[...]等）"""
    if HOLE not in sketch:
        return sketch

    lines = sketch.splitlines()
    hole_line_idx, _ = find_last_hole_linecol(sketch)
    if hole_line_idx < 0 or hole_line_idx >= len(lines):
        # 兜底：全局字符串层面替换“最后一个”
        pos = sketch.rfind(HOLE)
        return sketch[:pos] + fill + sketch[pos + len(HOLE):]

    ln = lines[hole_line_idx]
    pos = ln.rfind(HOLE)  # last hole in this line
    left = ln[:pos]
    right = ln[pos + len(HOLE):]

    fill = fill.rstrip("\n")
    fill_lines = fill.splitlines() if fill.strip() != "" else [""]

    # case A: <proof> 独占一行
    if ln.strip() == HOLE:
        indent = len(ln) - len(ln.lstrip(" "))
        pref = " " * indent
        new_block = []
        for fl in fill_lines:
            if fl.strip() == "":
                new_block.append("")
            else:
                new_block.append(pref + fl)
        lines = lines[:hole_line_idx] + new_block + lines[hole_line_idx+1:]
        return "\n".join(lines)

    # case B: 行内洞
    if len(fill_lines) == 1:
        lines[hole_line_idx] = left + fill_lines[0] + right
        return "\n".join(lines)

    # 多行 term：括号包裹，right 放最后
    line_indent = len(ln) - len(ln.lstrip(" "))
    cont_indent = " " * (line_indent + 2)

    lines[hole_line_idx] = left + "(" + fill_lines[0]

    mid = []
    for fl in fill_lines[1:-1]:
        if fl.strip() == "":
            mid.append("")
        else:
            mid.append(cont_indent + fl)

    last = fill_lines[-1]
    if last.strip() == "":
        mid.append(cont_indent + ")" + right)
    else:
        mid.append(cont_indent + last + ")" + right)

    lines = lines[:hole_line_idx+1] + mid + lines[hole_line_idx+1:]
    return "\n".join(lines)

   
   
   
   

def build_prompt(tokenizer, header: str, theorem: str, sketch_state: str) -> str:
    user = (
        "Fill the LAST <proof> in the following Lean 4 sketch.\n\n"
        "[HEADER]\n"
        f"{header}\n\n"
        "[THEOREM+SKETCH]\n"
        f"{theorem}\n"
        f"{sketch_state}\n"
    )
    msgs = [{"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user}]
    if getattr(tokenizer, "chat_template", None):
        return tokenizer.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
    return f"<<SYS>>\n{SYSTEM_PROMPT}\n<</SYS>>\n\n<<USER>>\n{user}\n<</USER>>\n\n<<ASSISTANT>>\n"

def _stable_int_seed(s: str) -> int:
    return int(hashlib.md5(s.encode("utf-8")).hexdigest(), 16) % (2**31 - 1)

def _safe_key(s: str) -> str:
    return re.sub(r"[^0-9A-Za-z._-]+", "_", str(s))

def main():
    cfg_path = os.environ["RUN_CONFIG_PATH"]
    sketch_jsonl = os.environ["SKETCH_JSONL"]
    out_jsonl = os.environ["OUT_JSONL"]

    max_new = int(os.environ.get("MAX_NEW_TOKENS_PER_HOLE", "256"))
    max_holes = int(os.environ.get("MAX_HOLES_PER_PROOF", "32"))
    do_sample = bool(int(os.environ.get("DO_SAMPLE", "0")))
    temperature = float(os.environ.get("TEMPERATURE", "0.2"))
    top_p = float(os.environ.get("TOP_P", "0.95"))

    # pass@k：每题生成几次完整尝试
    k_attempts = int(os.environ.get("K_ATTEMPTS", "1"))
    seed_base  = int(os.environ.get("GEN_SEED_BASE", "1234"))

    adapter_dir = os.environ.get("ADAPTER_DIR", "")
    tokenizer_dir = os.environ.get("TOKENIZER_DIR", "")

    cfg = json.loads(Path(cfg_path).read_text(encoding="utf-8"))
    base_model = cfg["base_model"]
    out_dir_root = cfg.get("out_dir", "")

    if not adapter_dir:
        adapter_dir = out_dir_root
    adapter_dir = resolve_adapter_dir(adapter_dir)

    if not tokenizer_dir:
        tokenizer_dir = out_dir_root

    rank = int(os.environ.get("RANK", "0"))
    world = int(os.environ.get("WORLD_SIZE", "1"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    torch.cuda.set_device(local_rank)

    outp = Path(out_jsonl)
    # DDP 推荐传目录：out_jsonl=/path/to/gen_dir
    if outp.suffix == ".jsonl":
        out_file = outp
        out_file.parent.mkdir(parents=True, exist_ok=True)
    else:
        outp.mkdir(parents=True, exist_ok=True)
        out_file = outp / f"gen_rank{rank}.jsonl"

    if rank == 0:
        print("base_model:", base_model)
        print("tokenizer_dir:", tokenizer_dir)
        print("adapter_dir:", adapter_dir)
        print("out_file:", out_file)
        print("K_ATTEMPTS:", k_attempts)

    tokenizer = AutoTokenizer.from_pretrained(tokenizer_dir, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.add_special_tokens({"additional_special_tokens": [HOLE, EOFILL]})
    tokenizer.truncation_side = "right"
    tokenizer.padding_side = "left"

    eofill_id = tokenizer.convert_tokens_to_ids(EOFILL)
    stop_id = eofill_id if (eofill_id is not None and eofill_id >= 0) else tokenizer.eos_token_id

    bnb_cfg = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True,
        bnb_4bit_compute_dtype=torch.bfloat16,
    )
    model = AutoModelForCausalLM.from_pretrained(
        base_model,
        quantization_config=bnb_cfg,
        device_map={"": local_rank},
        torch_dtype=torch.bfloat16,
    )
    model.resize_token_embeddings(len(tokenizer))
    model = PeftModel.from_pretrained(model, adapter_dir, is_trainable=False)
    model.eval()

    data = load_jsonl(sketch_jsonl)

    # 若存在 split 字段则优先按 split==test；否则默认整文件就是测试集
    if any(("split" in x) for x in data):
        test = [x for x in data if x.get("split") == "test"]
        if not test:
            test = [x for x in data if x.get("split") == "valid"]
        if not test:
            test = data
    else:
        test = data

    # shard
    test = test[rank::world]

    t0 = time.time()
    n_lines = 0
    with open(out_file, "w", encoding="utf-8") as w:
        for ex in test:
            rid = ex.get("id", "")
            header = ex.get("header", "") or ""
            theorem = ex.get("theorem", "") or ""

            sketch = ex.get("sketch", "")
            if not sketch:
                sketch = ex.get("proof", "") or ""

            for attempt in range(k_attempts):
                # 每题每次 attempt 固定 seed（保证可复现）
                seed = (seed_base + _stable_int_seed(f"{rid}__{attempt}")) % (2**31 - 1)
                torch.manual_seed(seed)
                torch.cuda.manual_seed_all(seed)

                cur = sketch
                steps = []

                for step in range(max_holes):
                    if HOLE not in cur:
                        break

                    prompt = build_prompt(tokenizer, header, theorem, cur)
                    enc = tokenizer(
                        prompt,
                        return_tensors="pt",
                        truncation=True,
                        max_length=int(cfg.get("max_len", 8192)),
                    )
                    input_ids = enc["input_ids"].to(model.device)
                    attn = enc["attention_mask"].to(model.device)
                    in_len = input_ids.shape[-1]

                    # K_ATTEMPTS>1 时，强制采样更有意义
                    do_sample_eff = do_sample or (k_attempts > 1)

                    with torch.no_grad():
                        gen = model.generate(
                            input_ids=input_ids,
                            attention_mask=attn,
                            max_new_tokens=max_new,
                            do_sample=do_sample_eff,
                            temperature=temperature if do_sample_eff else None,
                            top_p=top_p if do_sample_eff else None,
                            eos_token_id=stop_id,
                            pad_token_id=tokenizer.pad_token_id,
                        )

                    out_text = tokenizer.decode(gen[0][in_len:], skip_special_tokens=False)
                    fill = clean_fill(out_text)

                    # 截断/括号不平衡：重试一次（保留原逻辑）
                    if _looks_truncated_lean(fill):
                        gen2 = model.generate(
                            input_ids=input_ids,
                            attention_mask=attn,
                            max_new_tokens=max_new * 2,
                            do_sample=True,
                            temperature=max(0.7, temperature),
                            top_p=top_p,
                            eos_token_id=stop_id,
                            pad_token_id=tokenizer.pad_token_id,
                        )
                        out_text2 = tokenizer.decode(gen2[0][in_len:], skip_special_tokens=False)
                        fill2 = clean_fill(out_text2)
                        if not _looks_truncated_lean(fill2):
                            out_text, fill = out_text2, fill2

                    steps.append({
                        "gen_step": step,                 # 0-based
                        "gen_input_sketch": cur,          # 该步输入给模型的 sketch
                        "gen_fill": fill,                 # 清洗后的填充值
                        "gen_raw": out_text,              # 原始模型输出（含 <eofill> 等）
                    })

                    cur = insert_last_hole(cur, fill)

                final_body = normalize_body_for_by(cur)
                final_lean = header.strip() + "\n\n" + theorem.rstrip() + "\n" + final_body + "\n"

                # 保留输入所有字段
                rec = dict(ex)

                # ===== 新增：每条生成记录独有的 ID（不覆盖输入 id）=====
                # 语义：同一道题 id + 第几次 attempt
                gen_uid = f"{rid}__a{attempt:02d}"
                gen_case_key = _safe_key(gen_uid)   # 用于文件名/路径安全

                rec.update({
                    "gen_uid": gen_uid,             # ✅ 你要的“每个样本独有的id”
                    "gen_case_key": gen_case_key,   # ✅ 继续给 verify 用于 .lean 文件名

                    "gen_attempt": attempt,
                    "gen_seed": seed,
                    "gen_rank": rank,
                    "gen_world": world,

                    "gen_sketch_init": sketch,
                    "gen_num_fills": len(steps),
                    "gen_still_has_hole": (HOLE in cur),
                    "gen_final_lean": final_lean,
                    "gen_steps": steps,
                })

                w.write(json.dumps(rec, ensure_ascii=False) + "\n")
                n_lines += 1

    if rank == 0:
        print(f"done. rank0 wrote {n_lines} lines. elapsed={time.time()-t0:.1f}s")

if __name__ == "__main__":
    main()
