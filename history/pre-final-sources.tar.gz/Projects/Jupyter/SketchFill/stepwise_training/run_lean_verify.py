
import os, json, time, subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

def load_jsonl(path: str):
    items = []
    with open(path, "r", encoding="utf-8") as f:
        for ln in f:
            ln = ln.strip()
            if not ln:
                continue
            items.append(json.loads(ln))
    return items

def run_one(lean_proj: str, rid: str, lean_code: str, timeout: int):
    # 写入文件
    proj = Path(lean_proj)
    out_dir = proj / "ProofAttempts"
    out_dir.mkdir(parents=True, exist_ok=True)

    lean_path = out_dir / f"{rid}.lean"
    lean_path.write_text(lean_code, encoding="utf-8")

    cmd = f'cd "{proj}" && lake env lean "{lean_path.relative_to(proj)}"'
    t0 = time.time()
    try:
        p = subprocess.run(
            ["bash", "-lc", cmd],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            text=True,
        )
        ok = (p.returncode == 0)
        err_tail = (p.stderr or "")[-4000:]
        out_tail = (p.stdout or "")[-2000:]
        return {
            "id": rid,
            "pass": ok,
            "returncode": p.returncode,
            "time_sec": round(time.time()-t0, 3),
            "lean_path": str(lean_path),
            "stderr_tail": err_tail,
            "stdout_tail": out_tail,
        }
    except subprocess.TimeoutExpired:
        return {
            "id": rid,
            "pass": False,
            "returncode": -9,
            "time_sec": round(time.time()-t0, 3),
            "lean_path": str(lean_path),
            "stderr_tail": f"TIMEOUT after {timeout}s",
            "stdout_tail": "",
        }

def main():
    gen_jsonl = os.environ["GEN_JSONL"]
    lean_proj = os.environ["LEAN_PROJ"]
    out_jsonl = os.environ["OUT_JSONL"]
    timeout = int(os.environ.get("TIMEOUT", "120"))
    jobs = int(os.environ.get("JOBS", "8"))

    items = load_jsonl(gen_jsonl)
    Path(out_jsonl).parent.mkdir(parents=True, exist_ok=True)

    t0 = time.time()
    results = []
    with ThreadPoolExecutor(max_workers=jobs) as ex:
        futs = []
        for it in items:
            rid = it.get("id", "noid")
            lean_code = it["final_lean"]
            futs.append(ex.submit(run_one, lean_proj, rid, lean_code, timeout))

        for fut in as_completed(futs):
            results.append(fut.result())

    # 写 jsonl
    with open(out_jsonl, "w", encoding="utf-8") as w:
        for r in results:
            w.write(json.dumps(r, ensure_ascii=False) + "\n")

    passed = sum(1 for r in results if r["pass"])
    total = len(results)
    print(f"verified {total} files. pass={passed} ({passed/total*100:.2f}%). elapsed={time.time()-t0:.1f}s")
    print("out:", out_jsonl)

if __name__ == "__main__":
    main()
