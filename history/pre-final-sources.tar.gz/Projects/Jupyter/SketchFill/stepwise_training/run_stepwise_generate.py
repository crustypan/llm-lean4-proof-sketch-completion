
import os, re, json, time
from pathlib import Path

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from peft import PeftModel

EOFILL = "<eofill>"
HOLE = "<proof>"

SYSTEM_PROMPT = (
    "You are a Lean 4 proof completion model.\n"
    "Given a Lean 4 sketch with one or more <proof> holes, output ONLY the Lean code "
    "that should replace the FIRST <proof>.\n"
    "Do not output explanations. Do not repeat the input.\n"
    "End your output with the token <eofill>.\n"
)

def resolve_adapter_dir(adapter_dir: str) -> str:
    """adapter_dir 可以是 checkpoint-xxx 或 out_dir 根目录（自动挑最新 checkpoint）"""
    import re
    p = Path(adapter_dir)
    if (p / "adapter_config.json").exists():
        return str(p)
    cands = []
    for ck in p.glob("checkpoint-*"):
        if (ck / "adapter_config.json").exists():
            m = re.search(r"checkpoint-(\d+)", ck.name)
            step = int(m.group(1)) if m else -1
            cands.append((step, ck))
    if cands:
        cands.sort()
        return str(cands[-1][1])
    raise FileNotFoundError(f"adapter_config.json not found under: {p}")

def load_jsonl(path: str):
    items = []
    with open(path, "r", encoding="utf-8") as f:
        for ln in f:
            ln = ln.strip()
            if not ln:
                continue
            items.append(json.loads(ln))
    return items

def normalize_body_for_by(block: str) -> str:
    """保证 theorem ... := by 后面的 proof body 每行至少缩进 2 空格"""
    out = []
    for ln in block.splitlines():
        if ln.strip() == "":
            out.append("")
        elif ln.startswith("  "):
            out.append(ln)
        else:
            out.append("  " + ln)
    return "\n".join(out)

_CODEFENCE_RE = re.compile(r"^```.*?\n|\n```$", re.S)

def clean_fill(text: str) -> str:
    # 去掉 code fence
    t = text.strip()
    t = _CODEFENCE_RE.sub("", t).strip()
    # 取 <eofill> 前
    if EOFILL in t:
        t = t.split(EOFILL, 1)[0]
    # 常见多余
    t = t.replace(HOLE, "").strip("\n")
    return t.rstrip()

def find_first_hole_linecol(s: str):
    idx = s.find(HOLE)
    if idx < 0:
        return -1, -1
    # 行号与列
    line = s.count("\n", 0, idx)
    col = idx - (s.rfind("\n", 0, idx) + 1)
    return line, col

def insert_first_hole(sketch: str, fill: str) -> str:
    """把 fill 插入 sketch 的第一个 <proof>，尽量保持缩进"""
    if HOLE not in sketch:
        return sketch

    lines = sketch.splitlines()
    hole_line_idx, _ = find_first_hole_linecol(sketch)
    if hole_line_idx < 0 or hole_line_idx >= len(lines):
        # fallback：直接替换
        return sketch.replace(HOLE, fill, 1)

    ln = lines[hole_line_idx]
    # 计算 <proof> 位置
    pos = ln.find(HOLE)
    left = ln[:pos]
    right = ln[pos + len(HOLE):]

    # 行内 or 独占一行
    fill_lines = fill.splitlines() if fill.strip() != "" else [""]

    # 如果是独占一行（去掉空白后就是 <proof>）
    if ln.strip() == HOLE:
        indent = len(ln) - len(ln.lstrip(" "))
        pref = " " * indent
        new_block = []
        for fl in fill_lines:
            if fl.strip() == "":
                new_block.append("")
            else:
                new_block.append(pref + fl)
        lines = lines[:hole_line_idx] + new_block + lines[hole_line_idx+1:]
        return "\n".join(lines)

    # 行内：如果 fill 单行，直接替换
    if len(fill_lines) == 1:
        lines[hole_line_idx] = left + fill_lines[0] + right
        return "\n".join(lines)

    # 行内多行：第一行替换，后续行插入到下一行，缩进按 left 的缩进 + 2
    base_indent = len(left) - len(left.lstrip(" "))
    cont_indent = " " * (base_indent + 2)
    lines[hole_line_idx] = left + fill_lines[0] + right
    rest = []
    for fl in fill_lines[1:]:
        if fl.strip() == "":
            rest.append("")
        else:
            rest.append(cont_indent + fl)
    lines = lines[:hole_line_idx+1] + rest + lines[hole_line_idx+1:]
    return "\n".join(lines)

def build_prompt(tokenizer, header: str, theorem: str, sketch_state: str) -> str:
    user = (
        "Fill the FIRST <proof> in the following Lean 4 sketch.\n\n"
        "[HEADER]\n"
        f"{header}\n\n"
        "[THEOREM+SKETCH]\n"
        f"{theorem}\n"
        f"{sketch_state}\n"
    )
    msgs = [{"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user}]
    if getattr(tokenizer, "chat_template", None):
        return tokenizer.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
    # fallback
    return f"<<SYS>>\n{SYSTEM_PROMPT}\n<</SYS>>\n\n<<USER>>\n{user}\n<</USER>>\n\n<<ASSISTANT>>\n"

def main():
    # ---- env / args ----
    cfg_path = os.environ["RUN_CONFIG_PATH"]
    sketch_jsonl = os.environ["SKETCH_JSONL"]
    out_jsonl = os.environ["OUT_JSONL"]

    max_new = int(os.environ.get("MAX_NEW_TOKENS_PER_HOLE", "256"))
    max_holes = int(os.environ.get("MAX_HOLES_PER_PROOF", "32"))
    do_sample = bool(int(os.environ.get("DO_SAMPLE", "0")))
    temperature = float(os.environ.get("TEMPERATURE", "0.2"))
    top_p = float(os.environ.get("TOP_P", "0.95"))

    adapter_dir = os.environ.get("ADAPTER_DIR", "")
    tokenizer_dir = os.environ.get("TOKENIZER_DIR", "")

    cfg = json.loads(Path(cfg_path).read_text(encoding="utf-8"))
    base_model = cfg["base_model"]
    out_dir_root = cfg.get("out_dir", "")

    # resolve adapter dir
    if not adapter_dir:
        adapter_dir = out_dir_root
    adapter_dir = resolve_adapter_dir(adapter_dir)

    # tokenizer dir: 优先 env，其次 out_dir 根目录
    if not tokenizer_dir:
        tokenizer_dir = out_dir_root

    # ddp info
    rank = int(os.environ.get("RANK", "0"))
    world = int(os.environ.get("WORLD_SIZE", "1"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    torch.cuda.set_device(local_rank)

    # output file per-rank
    outp = Path(out_jsonl)
    if outp.suffix == ".jsonl":
        out_file = outp
        out_file.parent.mkdir(parents=True, exist_ok=True)
    else:
        outp.mkdir(parents=True, exist_ok=True)
        out_file = outp / f"gen_rank{rank}.jsonl"

    if rank == 0:
        print("base_model:", base_model)
        print("tokenizer_dir:", tokenizer_dir)
        print("adapter_dir:", adapter_dir)
        print("out_file:", out_file)

    # ---- load tokenizer/model ----
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_dir, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.add_special_tokens({"additional_special_tokens": [HOLE, EOFILL]})
    tokenizer.truncation_side = "left"

    eofill_id = tokenizer.convert_tokens_to_ids(EOFILL)
    eos_ids = [tokenizer.eos_token_id]
    if eofill_id is not None and eofill_id >= 0:
        eos_ids.append(eofill_id)

    bnb_cfg = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True,
        bnb_4bit_compute_dtype=torch.bfloat16,
    )
    model = AutoModelForCausalLM.from_pretrained(
        base_model,
        quantization_config=bnb_cfg,
        device_map={"": local_rank},
        torch_dtype=torch.bfloat16,
    )
    model.resize_token_embeddings(len(tokenizer))
    model = PeftModel.from_pretrained(model, adapter_dir, is_trainable=False)
    model.eval()

    # ---- load data ----
    data = load_jsonl(sketch_jsonl)
    test = [x for x in data if x.get("split") == "test"]
    if not test:
        test = [x for x in data if x.get("split") == "valid"]
    # shard
    test = test[rank::world]

    t0 = time.time()
    n = 0
    with open(out_file, "w", encoding="utf-8") as w:
        for ex in test:
            rid = ex.get("id", "")
            header = ex.get("header", "") or ""
            theorem = ex.get("theorem", "") or ""
            # sketch 空就用 proof（等价于“无需补洞”）
            sketch = ex.get("sketch", "")
            if not sketch:
                sketch = ex.get("proof", "") or ""

            cur = sketch
            steps = []
            for step in range(max_holes):
                if HOLE not in cur:
                    break

                prompt = build_prompt(tokenizer, header, theorem, cur)
                enc = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=int(cfg.get("max_len", 8192)))
                input_ids = enc["input_ids"].to(model.device)
                attn = enc["attention_mask"].to(model.device)
                in_len = input_ids.shape[-1]

                with torch.no_grad():
                    gen = model.generate(
                        input_ids=input_ids,
                        attention_mask=attn,
                        max_new_tokens=max_new,
                        do_sample=do_sample,
                        temperature=temperature if do_sample else None,
                        top_p=top_p if do_sample else None,
                        eos_token_id=eos_ids,
                        pad_token_id=tokenizer.pad_token_id,
                    )

                out_text = tokenizer.decode(gen[0][in_len:], skip_special_tokens=False)
                fill = clean_fill(out_text)

                cur2 = insert_first_hole(cur, fill)
                steps.append({
                    "step": step,
                    "fill": fill,
                    "raw": out_text,
                })
                cur = cur2

            final_body = normalize_body_for_by(cur)
            final_lean = header.strip() + "\n\n" + theorem.rstrip() + "\n" + final_body + "\n"

            rec = {
                "id": rid,
                "name": ex.get("name", ""),
                "source_id": ex.get("source_id", None),
                "sample_index": ex.get("sample_index", None),
                "split": ex.get("split", ""),
                "num_fills": len(steps),
                "still_has_hole": (HOLE in cur),
                "final_lean": final_lean,
                "steps": steps,
            }
            w.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n += 1

    if rank == 0:
        print(f"done. rank0 wrote {n} items. elapsed={time.time()-t0:.1f}s")

if __name__ == "__main__":
    main()
