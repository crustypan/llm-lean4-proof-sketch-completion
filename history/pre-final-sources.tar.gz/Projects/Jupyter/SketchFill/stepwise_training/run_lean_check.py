
import os, json, time, subprocess
from pathlib import Path
import jsonlines

def run_one(lean_proj: str, lean_path: Path, timeout_sec=120):
    # 在 lean_proj 下调用 lake env lean <file>
    t0 = time.time()
    p = subprocess.run(
        ["lake", "env", "lean", str(lean_path)],
        cwd=lean_proj,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=timeout_sec,
    )
    dt = time.time() - t0
    ok = (p.returncode == 0)
    out = p.stdout[-4000:]  # 截断，避免日志过大
    return ok, dt, out

def main():
    gen_jsonl = os.environ["GEN_JSONL"]
    out_jsonl = os.environ["OUT_JSONL"]
    lean_proj = os.environ["LEAN_PROJ"]
    timeout_sec = int(os.environ.get("LEAN_TIMEOUT", "120"))

    out_dir = Path(out_jsonl).parent
    proof_dir = Path(lean_proj) / "ProofAttempts"
    proof_dir.mkdir(parents=True, exist_ok=True)

    with jsonlines.open(gen_jsonl, "r") as r, jsonlines.open(out_jsonl, "w") as w:
        for ex in r:
            rid = ex.get("id")
            name = ex.get("name")
            final_lean = ex.get("final_lean", "")

            if not final_lean.strip():
                w.write({"id": rid, "name": name, "ok": False, "reason": "empty_final_lean"})
                continue

            lean_path = proof_dir / f"{rid}.lean"
            lean_path.write_text(final_lean, encoding="utf-8")

            try:
                ok, dt, out = run_one(lean_proj, lean_path, timeout_sec=timeout_sec)
                w.write({
                    "id": rid,
                    "name": name,
                    "ok": ok,
                    "time_sec": dt,
                    "leftover_proof_tokens": ex.get("leftover_proof_tokens", None),
                    "num_fills": ex.get("num_fills", None),
                    "lean_output_tail": out,
                })
            except subprocess.TimeoutExpired:
                w.write({
                    "id": rid,
                    "name": name,
                    "ok": False,
                    "time_sec": timeout_sec,
                    "reason": "timeout",
                })

if __name__ == "__main__":
    main()
