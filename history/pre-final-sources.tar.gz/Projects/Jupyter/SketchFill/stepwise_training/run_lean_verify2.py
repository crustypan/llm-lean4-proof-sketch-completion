
import os, json, time, subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

def tail(s: str, n: int = 4000) -> str:
    if s is None:
        return ""
    return s[-n:]

def pick_code(ex: dict) -> str:
    # 兼容不同字段名：按常见顺序取“最终可验证 Lean 源码”
    for k in ["lean_code", "final_lean", "filled_lean", "lean_proof", "code"]:
        v = ex.get(k)
        if isinstance(v, str) and v.strip():
            return v

    # 兜底：尝试拼装（如果你的 gen jsonl 只存了部分字段）
    header = ex.get("header", "") or ""
    theorem = ex.get("theorem", "") or ""
    proof = ex.get("proof_filled", "") or ex.get("proof", "") or ""
    return header + "\n\n" + theorem + "\n" + proof

def run_one(ex: dict, lean_proj: str, out_dir: Path, timeout: int, lake_bin: str):
    rid = ex.get("id", "")
    code = pick_code(ex)

    out_path = out_dir / f"{rid}.lean"
    out_path.write_text(code, encoding="utf-8")

    t0 = time.time()
    cmd = [lake_bin, "env", "lean", str(out_path)]

    try:
        p = subprocess.run(
            cmd,
            cwd=lean_proj,          # ✅ 关键：让 lake 读取 lean-toolchain
            capture_output=True,
            text=True,
            timeout=timeout,
            env=os.environ.copy(),
        )
        ok = (p.returncode == 0)
        tag = "pass" if ok else "lean_error"
        return {
            "id": rid,
            "pass": bool(ok),
            "tag": tag,
            "returncode": p.returncode,
            "elapsed": time.time() - t0,
            "lean_file": str(out_path),
            "stdout_tail": tail(p.stdout),
            "stderr_tail": tail(p.stderr),
        }

    except subprocess.TimeoutExpired as e:
        return {
            "id": rid,
            "pass": False,
            "tag": "timeout",
            "returncode": None,
            "elapsed": time.time() - t0,
            "lean_file": str(out_path),
            "stdout_tail": tail(getattr(e, "stdout", "")),
            "stderr_tail": tail(getattr(e, "stderr", "")),
        }

    except FileNotFoundError as e:
        return {
            "id": rid,
            "pass": False,
            "tag": "lake_not_found",
            "returncode": None,
            "elapsed": time.time() - t0,
            "lean_file": str(out_path),
            "stdout_tail": "",
            "stderr_tail": str(e),
        }

    except Exception as e:
        return {
            "id": rid,
            "pass": False,
            "tag": "other",
            "returncode": None,
            "elapsed": time.time() - t0,
            "lean_file": str(out_path),
            "stdout_tail": "",
            "stderr_tail": repr(e),
        }

def main():
    gen_jsonl = os.environ["GEN_JSONL"]
    lean_proj = os.environ["LEAN_PROJ"]
    out_jsonl = os.environ["OUT_JSONL"]
    timeout = int(os.environ.get("TIMEOUT", "1200"))
    jobs = int(os.environ.get("JOBS", "8"))
    lake_bin = os.environ.get("LAKE", "lake")   # ✅ 允许传绝对路径

    out_jsonl_p = Path(out_jsonl)
    out_jsonl_p.parent.mkdir(parents=True, exist_ok=True)

    out_dir = out_jsonl_p.parent / "lean_files"
    out_dir.mkdir(parents=True, exist_ok=True)

    items = []
    with open(gen_jsonl, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            items.append(json.loads(line))

    t0 = time.time()
    passed = 0

    with open(out_jsonl, "w", encoding="utf-8") as w:
        with ThreadPoolExecutor(max_workers=jobs) as ex:
            futs = [ex.submit(run_one, it, lean_proj, out_dir, timeout, lake_bin) for it in items]
            for fut in as_completed(futs):
                r = fut.result()
                if r.get("pass"):
                    passed += 1
                w.write(json.dumps(r, ensure_ascii=False) + "\n")

    print(f"verified {len(items)} files. pass={passed} ({passed/len(items)*100:.2f}%). elapsed={time.time()-t0:.1f}s")
    print("out:", out_jsonl)

if __name__ == "__main__":
    main()
