#!/usr/bin/env python3
# 3_train_two_stage.py
# Two-stage SFT training (A: full SFT; B: gap-focused SFT) using qLoRA+LoRA (PEFT).
# Compatible with modern trl: removes response_template usage; adds rope_scaling fix and --max_steps.

import os
import argparse
from pathlib import Path
import math
import random
import json

from datasets import load_dataset
from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments, BitsAndBytesConfig
from trl import SFTTrainer
from peft import LoraConfig

# -------------------------
# Utility dataset helpers
# -------------------------
def load_jsonl_as_dataset(p):
    # returns a HF dataset split "train" from single file
    return load_dataset("json", data_files=str(p), split="train")

def simple_formatting_full(examples, tokenizer=None):
    out = []
    for inp, tgt in zip(examples["input"], examples["target"]):
        prompt = inp.rstrip() + "\n\n```lean4\n"
        out.append(prompt + tgt)
    return out

def simple_formatting_gap(examples, tokenizer=None):
    out = []
    for inp, tgt in zip(examples["input"], examples["target"]):
        prompt = inp.rstrip() + "\n\n```lean4\n"
        out.append(prompt + tgt)
    return out

# -------------------------
# Core training stage
# -------------------------
def run_stage(stage_name,
              model_name_or_path,
              train_jsonl,
              eval_jsonl,
              output_dir,
              use_qlora=True,
              max_seq_len=4096,
              per_device_bs=1,
              grad_acc=16,
              lr=1e-4,
              epochs=3,
              bf16=False,
              fp16=True,
              save_steps=500,
              eval_steps=500,
              resume_from=None,
              max_steps=None,
              dataset_num_proc=4):
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    # tokenizer
    tok = AutoTokenizer.from_pretrained(model_name_or_path, use_fast=False, trust_remote_code=True)
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token

    # quantization config (qLoRA)
    quant_cfg = None
    if use_qlora:
        quant_cfg = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype="float16",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
        )

    # load model (device_map='auto' works with accelerate/transformers auto device placement)
    model = AutoModelForCausalLM.from_pretrained(
        model_name_or_path,
        trust_remote_code=True,
        device_map="auto",
        quantization_config=quant_cfg,
    )

    # --- Fix rope_scaling config incompatibilities (best-effort) ---
    try:
        if hasattr(model.config, "rope_scaling") and isinstance(model.config.rope_scaling, dict):
            rs = model.config.rope_scaling
            rs_fixed = {}
            # ensure factor is float >= 1
            if "factor" in rs:
                try:
                    rs_fixed["factor"] = float(rs.get("factor", 1.0))
                    if rs_fixed["factor"] < 1.0:
                        rs_fixed["factor"] = 1.0
                except Exception:
                    rs_fixed["factor"] = 1.0
            else:
                rs_fixed["factor"] = 1.0
            # optional beta fields
            if "beta_fast" in rs:
                try:
                    rs_fixed["beta_fast"] = float(rs["beta_fast"])
                except Exception:
                    pass
            if "beta_slow" in rs:
                try:
                    rs_fixed["beta_slow"] = float(rs["beta_slow"])
                except Exception:
                    pass
            model.config.rope_scaling = rs_fixed
    except Exception:
        try:
            delattr(model.config, "rope_scaling")
        except Exception:
            pass

    # LoRA (PEFT) config
    peft_cfg = LoraConfig(
        r=32,
        lora_alpha=32,
        lora_dropout=0.1,
        target_modules="all-linear",
        task_type="CAUSAL_LM",
    )

    # datasets
    ds_train = load_jsonl_as_dataset(train_jsonl)
    ds_eval = load_jsonl_as_dataset(eval_jsonl) if eval_jsonl else None

    # choose formatting fns
    fmt = simple_formatting_full if stage_name == "A" else simple_formatting_gap

    # TrainingArguments mapping
    training_args = TrainingArguments(
        output_dir=output_dir,
        num_train_epochs=epochs,
        per_device_train_batch_size=per_device_bs,
        per_device_eval_batch_size=per_device_bs,
        gradient_accumulation_steps=grad_acc,
        evaluation_strategy="steps" if ds_eval is not None else "no",
        eval_steps=eval_steps,
        save_strategy="steps",
        save_steps=save_steps,
        save_total_limit=3,
        learning_rate=lr,
        bf16=bf16,
        fp16=fp16 and not bf16,
        logging_steps=50,
        lr_scheduler_type="cosine",
        warmup_ratio=0.03,
        report_to="tensorboard",
    )

    # If max_steps specified, override via training_args attribute (Trainer respects it)
    if max_steps is not None:
        training_args.max_steps = int(max_steps)

    # SFTTrainer -- note: do NOT pass response_template (some trl versions don't accept it)
    trainer = SFTTrainer(
        model=model,
        tokenizer=tok,
        train_dataset=ds_train,
        eval_dataset=ds_eval,
        peft_config=peft_cfg,
        max_seq_length=max_seq_len,
        packing=False,
        formatting_func=lambda ex: fmt(ex, tokenizer=tok),
        dataset_num_proc=dataset_num_proc,
        args=training_args
    )

    # Resume from a PEFT checkpoint if provided
    if resume_from:
        try:
            print(f"Loading PEFT checkpoint from {resume_from}")
            trainer.load_pretrained(resume_from)
        except Exception as e:
            print("Warning: could not load pretrained PEFT from", resume_from, "error:", e)

    # Train
    trainer.train()

    # Save model and tokenizer and peft weights
    trainer.save_model(output_dir)
    tok.save_pretrained(output_dir)
    print(f"Stage {stage_name} finished and saved to {output_dir}")

    return output_dir

# -------------------------
# CLI and pipeline
# -------------------------
def main(args):
    out_root = Path(args.output_dir)
    out_root.mkdir(parents=True, exist_ok=True)

    # Stage A
    out_a = out_root / "stageA"
    run_stage(
        stage_name="A",
        model_name_or_path=args.model_name_or_path,
        train_jsonl=args.train_full,
        eval_jsonl=args.val_full,
        output_dir=str(out_a),
        use_qlora=not args.disable_qlora,
        max_seq_len=args.max_seq_len,
        per_device_bs=args.per_device_bs,
        grad_acc=args.grad_acc,
        lr=args.lr_a,
        epochs=int(args.epochs_a),
        bf16=args.bf16,
        fp16=args.fp16,
        save_steps=args.save_steps,
        eval_steps=args.eval_steps,
        max_steps=args.max_steps,
        dataset_num_proc=4
    )

    # Stage B: from stage A checkpoint
    out_b = out_root / "stageB"
    run_stage(
        stage_name="B",
        model_name_or_path=str(out_a),   # load from A checkpoint dir
        train_jsonl=args.train_gap,
        eval_jsonl=args.val_gap if args.val_gap else args.val_full,
        output_dir=str(out_b),
        use_qlora=not args.disable_qlora,
        max_seq_len=args.max_seq_len,
        per_device_bs=args.per_device_bs,
        grad_acc=args.grad_acc,
        lr=args.lr_b,
        epochs=int(args.epochs_b),
        bf16=args.bf16,
        fp16=args.fp16,
        save_steps=args.save_steps,
        eval_steps=args.eval_steps,
        resume_from=str(out_a),
        max_steps=args.max_steps,
        dataset_num_proc=4
    )

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_name_or_path", required=True)
    parser.add_argument("--train_full", required=True)
    parser.add_argument("--val_full", required=True)
    parser.add_argument("--train_gap", required=True)
    parser.add_argument("--val_gap", default=None)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--max_seq_len", type=int, default=4096)
    parser.add_argument("--per_device_bs", type=int, default=1)
    parser.add_argument("--grad_acc", type=int, default=16)
    parser.add_argument("--disable_qlora", action="store_true")
    parser.add_argument("--lr_a", type=float, default=1e-4)
    parser.add_argument("--lr_b", type=float, default=5e-5)
    parser.add_argument("--epochs_a", type=int, default=4)
    parser.add_argument("--epochs_b", type=int, default=6)
    parser.add_argument("--save_steps", type=int, default=500)
    parser.add_argument("--eval_steps", type=int, default=500)
    parser.add_argument("--bf16", action="store_true")
    parser.add_argument("--fp16", action="store_true")
    parser.add_argument("--max_steps", type=int, default=None,
                        help="If set, overrides epochs and runs at most max_steps training steps (useful for smoke tests).")
    args = parser.parse_args()
    main(args)